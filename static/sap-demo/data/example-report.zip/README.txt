Saved real-data SAP example output. No FCS analysis is performed in this browser preview. Original run identifiers and numerical outputs are preserved; local paths and serials are omitted.
