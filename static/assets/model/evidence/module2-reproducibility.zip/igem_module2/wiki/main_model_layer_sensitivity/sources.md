# Sources and scope

All figure values come from the completed 2026-09-29 main-model readout-depth experiment, not from the earlier local-embedding Ridge experiment.

- `data/metrics.csv`: grouped OOF metrics for 12 fixed layers and one nested layer-selection pipeline.
- `data/oof_rankings.csv`: 858 rows, 66 constructs per pipeline; all top-K overlaps and pair accuracies independently recomputed.
- `data/VALIDATED.json`: block-12 masked score parity and exact original-main-model OOF reproduction.
- `experiment/inputs/`: unchanged input files copied from the supplied Wiki's ablation experiment; hashes are in `data/protocol.json`.
- `experiment/run.py` and `experiment/model.py`: actual experiment implementation. Intermediate states pass through the frozen final encoder normalization and pretrained LM head before constructing the original scalar mutation score. After numerical parity, the immutable original layer-12 probability cache was reused to make the reference control exact.
- `scripts/orca_plot.py` and `scripts/orca-style.json`: copied from the user-provided ORCA scientific illustrator package; project typography and colors are inherited from the supplied Wiki style.

No new assays, confidence intervals, significance tests, or prospective validation were added. The shared final-trained head makes this a diagnostic intermediate readout; intermediate probabilities are not independently calibrated. Original deployed model weights are preserved.
