#### Sensitivity to ESM-2 readout depth

We tested whether using the final ESM-2 layer was an important modeling choice. This analysis retained the main model's **reference-masked mutation score + reference-centred one-hot encoding + Ridge** pipeline. Only the ESM-2 readout depth varied across blocks 1–12. The same 81-construct pool of observed C labels, 66 sequence-group outer test folds, inner partitions, Ridge penalties, score weights and A selection rule were retained. Missing measurements were never filled with zero; preprocessing and parameter selection used training records only.

At each substituted position, the reference sequence was masked and the mutant-minus-reference log probability was read from the selected layer, then summed across substitutions. For blocks 1–11, we applied the frozen final encoder normalization and the same pretrained vocabulary prediction head to the intermediate state. Block 12 used its native normalized output. This shared-head readout is a **logit-lens diagnostic**: the vocabulary head was trained for the final layer, so the intermediate probabilities are not independently trained or calibrated. The block-12 control reproduced the original main-model predictions within the recorded numerical tolerance. No local-embedding pooling or LoRA fitting was introduced.

![Main-model Spearman and pairwise ranking accuracy across ESM-2 readout layers](main_model_layer_sensitivity/figures/ranking/figure@2x.png)

*Figure 6. Main-model sensitivity to readout depth. The upper panel shows grouped outer-OOF Spearman correlation; the lower panel shows all-pair and within-batch pair accuracy. Pairs with observed |ΔS| ≤ 0.01 are excluded, and predicted ties contribute 0.5. The dashed reference in the upper panel is a separate pipeline that selects the layer only within each outer fold's inner validation. All twelve fixed-layer results are shown without smoothing or uncertainty intervals.*

The highest fixed-layer Spearman estimate was **0.515 at layer 4**, compared with **0.405 at layer 12**. These maxima describe the tested representations; they do not constitute an outer-test-based deployment selection.

![Main-model Top15 and Top30 recovery across all twelve ESM-2 readout layers](main_model_layer_sensitivity/figures/topk/figure@2x.png)

*Figure 7. Top15 and Top30 overlap for the same 66 complete-S constructs. Random expected overlap is K²/66: 3.41 for Top15 and 13.64 for Top30. Dashed lines show the inner-selected-layer pipeline. Top30 was added retrospectively for reporting and did not change the historical inner selection objective.*

The largest observed Top15 overlap was **6/15**, attained at layer(s) 3, 4, 6, 7, 10, 11, 12. The largest Top30 overlap was **20/30**, attained at layer(s) 1, 2, 3, 4, 9, 12; its random-selection enrichment was **1.47×**. Layer 12 recovered 6/15 and 20/30, respectively.

To separate sensitivity description from layer selection, we also selected the layer and Ridge configuration using only the inner validation of each outer fold. This pipeline reached **Spearman 0.323, Top15 4/15 and Top30 20/30**. It provides the relevant development-CV estimate for the layer-selection procedure. Selecting the best fixed layer after inspecting all outer scores would be optimistic. No statistical significance or independent experimental improvement is inferred, and the deployed model weights were not replaced by this analysis.

The [complete layer metrics](main_model_layer_sensitivity/data/metrics.csv), [per-construct OOF ranks](main_model_layer_sensitivity/data/oof_rankings.csv), [locked protocol](main_model_layer_sensitivity/data/protocol.json), [validation record](main_model_layer_sensitivity/data/VALIDATED.json) and [ORCA plotting script](main_model_layer_sensitivity/scripts/plot.py) accompany the figures.

