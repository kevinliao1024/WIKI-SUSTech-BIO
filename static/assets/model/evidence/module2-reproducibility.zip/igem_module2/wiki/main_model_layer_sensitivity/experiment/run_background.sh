#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p logs
if [[ "${1:-}" != --worker ]]; then
  exec 9>logs/lock
  flock -n 9 || exit 0
  if [[ -f logs/pid ]] && kill -0 "$(cat logs/pid)" 2>/dev/null; then echo RUNNING; exit 0; fi
  log="logs/run_$(date +%Y%m%d_%H%M%S).log"
  nohup bash "$0" --worker >"$log" 2>&1 </dev/null 9>&- &
  echo "$!" >logs/pid;echo "$log" >logs/current;echo "Started $!";exit 0
fi
export CUDA_VISIBLE_DEVICES=1 OMP_NUM_THREADS=2 MKL_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2
trap 'rc=$?; echo "$rc" >logs/exit_code; date -Is >logs/finished_at' EXIT
date -Is >logs/started_at
PY=/data/ydx/codex_runs/puf_apobec_20260905/work/.venv/bin/python
CK=/data/ydx/codex_runs/puf_prediction_20260926/work/esm2_t12_35M_UR50D
"$PY" -u run.py --checkpoint "$CK" --pilot
"$PY" -u run.py --checkpoint "$CK"
