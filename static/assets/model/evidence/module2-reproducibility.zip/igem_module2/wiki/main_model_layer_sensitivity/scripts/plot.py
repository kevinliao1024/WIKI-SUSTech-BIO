from pathlib import Path
import csv,hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from orca_plot import Theme,export
root=Path(__file__).resolve().parents[1]
metrics=list(csv.DictReader((root/'data/metrics.csv').open(encoding='utf-8-sig')))
rows=[next(r for r in metrics if r['method']==f'layer{i}' and r['subset']=='all') for i in range(1,13)]
selected=next(r for r in metrics if r['method']=='inner_selected_layer' and r['subset']=='all')
theme=Theme(root/'orca-figure-style.json',defaults=Path(__file__).with_name('orca-style.json'))
purple=theme.c['indigo700'];teal=theme.c['teal600'];orange=theme.c['orange500'];muted=theme.c['muted'];x=np.arange(1,13)
theme.config['chart_settings']['main_model_layer_sensitivity']={'layers':list(range(1,13)),'n':66,'panels':'two stacked axes per figure','height_in':10.5,'no_smoothing':True,'uncertainty':'not estimated'};theme.save()
prov={'sources':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'data').glob('*') if p.is_file()},'unit':'66 sequence-group OOF constructs, 81-construct observed-label training pool','method':'reference masked log odds + reference-centred one-hot + Ridge; original grid and A rule','readout':'frozen final encoder norm and shared pretrained LM head on intermediate states; native normalized state at layer12','limitations':'logit-lens diagnostic, intermediate probabilities not independently calibrated; exploratory development CV','pair_rule':'observed |delta S| >0.01; predicted ties score 0.5','uncertainty':'not estimated; no smoothing or layer exclusions'}
with theme.context():
    fig,axs=plt.subplots(2,1,figsize=(10,10.5),layout='constrained')
    rho=[float(r['Spearman']) for r in rows]
    axs[0].plot(x,rho,'-o',color=purple,markersize=7,label='Fixed layer')
    axs[0].axhline(float(selected['Spearman']),color=muted,ls='--',label='Inner-selected layer')
    axs[0].set(ylabel='Spearman correlation',ylim=(min(0,min(rho)-.08),max(.65,max(rho)+.12)));axs[0].legend(loc='upper left',ncol=2,fontsize=16)
    axs[1].plot(x,[float(r['pair_accuracy_all'])*100 for r in rows],'-o',color=purple,markersize=7,label='All eligible pairs')
    axs[1].plot(x,[float(r['pair_accuracy_within_batch'])*100 for r in rows],'--s',color=teal,markersize=6,label='Within-batch pairs')
    axs[1].axhline(50,color=muted,ls=':',lw=1.4);axs[1].set(ylabel='Pairwise accuracy (%)',ylim=(0,100),yticks=[0,25,50,75,100]);axs[1].legend(loc='upper left',ncol=2,fontsize=16)
    for ax in axs:ax.set(xlabel='ESM-2 Transformer layer',xticks=x,xlim=(.7,12.3));ax.grid(axis='y',color=theme.c['line'],alpha=.5)
    export(fig,root/'figures/ranking',theme,caption='Layer sensitivity of the main model pipeline: additive reference-masked ESM-2 score plus reference-centred one-hot encoding and Ridge. Upper: Spearman correlation for each fixed layer; the dashed line is the separately evaluated inner-selected-layer pipeline. Lower: all-pair and same-batch pair accuracy, omitting observed |delta S| <= 0.01; predicted ties contribute 0.5. All layers share the same 66 grouped outer test constructs, 81-construct observed-label training pool, inner partitions, Ridge grid and A selection. Intermediate states pass through the frozen final encoder normalization and shared pretrained vocabulary head; layer12 reproduces the native main-model score. No uncertainty intervals, smoothing or independent validation are implied.',alt_text='Two line charts compare all 12 layers using main-model Spearman and pairwise accuracy. Exact values, counts and the inner-selected result are supplied in metrics.csv.',provenance=prov);plt.close(fig)
    fig,axs=plt.subplots(2,1,figsize=(10,10.5),layout='constrained')
    for ax,k in zip(axs,[15,30]):
        counts=[int(float(r[f'Top{k}_overlap'])) for r in rows];nested=int(float(selected[f'Top{k}_overlap']))
        ax.plot(x,counts,'-o',color=purple,markersize=7,label='Fixed layer');ax.axhline(nested,color=muted,ls='--',label='Inner-selected layer');ax.axhline(k*k/66,color=orange,ls=':',linewidth=2.3,label='Random expectation')
        ax.set(ylabel=f'Measured Top{k} recovered',ylim=(0,k),yticks=np.arange(0,k+1,3 if k==15 else 5),xlabel='ESM-2 Transformer layer',xticks=x,xlim=(.7,12.3));ax.grid(axis='y',color=theme.c['line'],alpha=.5);ax.legend(loc='upper left',fontsize=15,ncol=2)
        for i,v in zip(x,counts):ax.annotate(str(v),(i,v),xytext=(0,9),textcoords='offset points',ha='center',fontsize=16)
    export(fig,root/'figures/topk',theme,caption='Top15 and Top30 recovery for the main ESM-score-plus-one-hot Ridge pipeline at each of 12 layers, evaluated among 66 complete-S constructs. Counts are overlaps between predicted and measured top-K sets. Random expected overlap is K²/66 (3.41 for Top15, 13.64 for Top30). Dashed lines report the inner-selected-layer pipeline. Top30 is a retrospective reporting cutoff; the historical inner objective remains unchanged. Point-estimate maxima are descriptive, without significance testing or independent validation.',alt_text='Two line charts show measured Top15 and Top30 recovery at all 12 main-model readout depths, with random expectation and inner-selected-layer references. All values are in metrics.csv.',provenance=prov);plt.close(fig)
print('Exported main-model ORCA figures; font',theme.font)
