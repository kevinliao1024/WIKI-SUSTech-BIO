from pathlib import Path
import csv,hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from orca_plot import Theme,export

root=Path(__file__).resolve().parents[1];source=root/'data/metrics.csv'
data=list(csv.DictReader(source.open(encoding='utf-8-sig')))
rows=[next(r for r in data if r['method']==f'layer{i}' and r['subset']=='all') for i in range(1,13)]
values=[float(r['Spearman']) for r in rows];nested=float(next(r for r in data if r['method']=='inner_selected_layer' and r['subset']=='all')['Spearman'])
theme=Theme(root/'orca-figure-style.json',defaults=Path(__file__).with_name('orca-style.json'))
with theme.context():
    fig,ax=theme.figure(width=10,height=8.5);y=np.arange(12)
    bars=ax.barh(y,values,height=.60,color=theme.c['indigo700'])
    ax.set(yticks=y,yticklabels=[f'Layer {i}' for i in range(1,13)],xlabel='Spearman correlation',xlim=(0,.63),xticks=np.arange(0,.61,.1));ax.invert_yaxis();ax.tick_params(axis='y',length=0);ax.spines['left'].set_visible(False)
    ax.axvline(nested,color=theme.c['muted'],linestyle='--',linewidth=1.7,label=f'Inner-selected layer: {nested:.3f}');ax.legend(loc='lower left',bbox_to_anchor=(0,1.01),fontsize=17,borderaxespad=0)
    for i,v in enumerate(values):ax.text(v+.01,i,f'{v:.3f}',ha='left',va='center',fontsize=18)
    assert len(bars)==12 and all(abs(b.get_width()-v)<1e-14 for b,v in zip(bars,values))
    export(fig,root/'figures/spearman',theme,caption='Spearman correlation for each ESM-2 readout layer in the main reference-masked-score + one-hot + Ridge pipeline. All 12 fixed layers are shown in numerical order; printed values are rounded to three decimals. Each value uses the same 66 sequence-group outer predictions and the same 81-construct observed-label training pool, inner partitions and Ridge grid. The dashed line marks the separately evaluated inner-selected-layer pipeline (0.323), not an additional fixed layer. Layer 4 has the highest observed fixed-layer value (0.515); layer 12 reproduces the original main model (0.405). Intermediate readout uses the shared frozen final normalization and vocabulary head. These are development-CV point estimates without uncertainty intervals or significance claims.',alt_text='Horizontal bars list Spearman for layers 1–12: 0.448, 0.444, 0.413, 0.515, 0.396, 0.359, 0.434, 0.351, 0.325, 0.340, 0.406 and 0.405. A dashed reference at 0.323 shows inner-only layer selection.',provenance={'source':'data/metrics.csv','sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'filter':'subset=all; layer1 through layer12, no omissions','unit':'construct-level grouped OOF, n=66','transform':'display rounding only; bar lengths use full precision','uncertainty':'not estimated','no_retraining':True});plt.close(fig)
print('Exported all 12 layer Spearman values')
