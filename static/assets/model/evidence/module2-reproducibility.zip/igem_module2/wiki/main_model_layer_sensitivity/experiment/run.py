from pathlib import Path
import argparse,json,time,math,hashlib,platform
import numpy as np,pandas as pd,torch,joblib,sklearn,transformers
from scipy.stats import spearmanr,kendalltau
from transformers import EsmForMaskedLM,AutoTokenizer
from model import AA,encode,fit,predict

def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,r):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(r,indent=2));tmp.replace(p)
def S(y):return y[:,1]-(y[:,0]+y[:,2])/2
def obj(y,q,ids):
    t=S(y);e=S(q);rho=float(spearmanr(t,e).statistic);rho=rho if np.isfinite(rho) else -1.;k=math.ceil(15/66*len(t));sel=np.lexsort((ids,-e))[:k];return [rho,float(t[sel].mean()),-float(np.mean((y-q)**2))]
def metric(d):
    y=d.S.to_numpy();p=d.S_hat.to_numpy();n=len(d);a,b=np.triu_indices(n,1);mask=np.abs(y[a]-y[b])>.01;direction=(y[a]-y[b])*(p[a]-p[b]);r=dict(n=n,Spearman=float(spearmanr(y,p).statistic),Kendall=float(kendalltau(y,p).statistic))
    for label,m in [('all',mask),('within_batch',mask&(d.batch.to_numpy()[a]==d.batch.to_numpy()[b]))]:r['pair_count_'+label]=int(m.sum());r['pair_accuracy_'+label]=float(((direction[m]>0)+.5*(direction[m]==0)).mean()) if m.any() else None
    for k in [5,10,15,30]:
        if n<k:continue
        top=d.sort_values(['S_hat','construct_id'],ascending=[False,True]).head(k);true=d.sort_values(['S','construct_id'],ascending=[False,True]).head(k);h=len(set(top.construct_id)&set(true.construct_id));r.update({f'Top{k}_overlap':h,f'Top{k}_hit_rate':h/k,f'Top{k}_enrichment_vs_random':h/(k*k/n),f'Top{k}_mean_S':float(top.S.mean())})
    return r

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--checkpoint',required=True);ap.add_argument('--pilot',action='store_true');a=ap.parse_args();root=Path(__file__).resolve().parent;inp=root/'inputs';cfg=json.loads((root/'protocol.json').read_text());torch.set_num_threads(2)
    for name,h in cfg['inputs'].items():assert digest(inp/name)==h
    assert digest(Path(a.checkpoint)/'model.safetensors')==cfg['checkpoint_sha256']
    prov=dict(protocol=digest(root/'protocol.json'),code={n:digest(root/n) for n in ['run.py','model.py']},torch=torch.__version__,transformers=transformers.__version__,sklearn=sklearn.__version__,python=platform.python_version())
    if (root/'provenance.json').exists():assert json.loads((root/'provenance.json').read_text())==prov
    else:save(root/'provenance.json',prov)
    mf=pd.read_csv(inp/'construct_manifest.csv');ta=pd.read_csv(inp/'construct_targets.csv');assert mf.construct_id.tolist()==ta.construct_id.tolist();Y=ta[['C295','C388','C871']].to_numpy(float);assert len(Y)==81 and np.isfinite(Y).all(1).sum()==66;ref=json.loads((inp/'reference.json').read_text())['reference'];old=np.load(inp/'reference_masked_logp.npy');groups=mf.leakage_group.to_numpy();folds=json.loads((inp/'splits.json').read_text());cache=root/'score_cache';cache.mkdir(exist_ok=True)
    needed=[b for b in range(0,8 if a.pilot else 493,8) if not (cache/f'{b:03}.npz').exists()]
    if needed:
        torch.cuda.set_per_process_memory_fraction(.7,0);m=EsmForMaskedLM.from_pretrained(a.checkpoint,local_files_only=True).to('cuda:0').eval();m.requires_grad_(False);tok=AutoTokenizer.from_pretrained(a.checkpoint,local_files_only=True);tokens=tok(ref,return_tensors='pt')['input_ids'].to('cuda:0');aaids=torch.tensor(tok.convert_tokens_to_ids(list(AA)),device='cuda:0');assert m.config.num_hidden_layers==12
        with torch.no_grad():
            for b in needed:
                pos=torch.arange(b,min(b+8,493),device='cuda:0');batch=tokens.repeat(len(pos),1);ix=torch.arange(len(pos),device='cuda:0');batch[ix,pos+1]=tok.mask_token_id;out=m(input_ids=batch,output_hidden_states=True);values={}
                for l in cfg['layers']:
                    h=out.hidden_states[l][ix,pos+1];h=m.esm.encoder.emb_layer_norm_after(h) if l<12 else h;logits=m.lm_head(h);values[f'layer{l}']=logits.log_softmax(-1)[:,aaids].cpu().numpy()
                delta=float(np.max(np.abs(values['layer12']-old[b:b+len(pos)])));assert delta<1e-4,delta
                np.savez(cache/f'{b:03}.npz',**values);print('SCORE',b+len(pos),'/493',flush=True)
        del m;torch.cuda.empty_cache()
    if a.pilot:
        onehot,score=encode(mf.puf_sequence.tolist(),ref,old);f=folds[0];sp=f['inner'][0];q=predict(fit(onehot,score,Y,np.array(sp['train81']),'Hsu_ESM2_OneHot_Ridge',dict(alpha=1,score_weight=1)),onehot,score,np.array(sp['validation66']));assert np.isfinite(q).all();save(root/'PILOT_PASSED.json',dict(masked_score_readout_reproduces_original_last_layer=True,small_fit_finite=True));return
    assert (root/'PILOT_PASSED.json').exists();logps={l:np.concatenate([np.load(cache/f'{b:03}.npz')[f'layer{l}'] for b in range(0,493,8)]) for l in cfg['layers']};maxerr=float(np.max(np.abs(logps[12]-old)));assert maxerr<1e-4
    # Reuse the immutable final-layer cache after numerical parity, so control is exact.
    logps[12]=old;scores={}
    for l in cfg['layers']:onehot,scores[l]=encode(mf.puf_sequence.tolist(),ref,logps[l])
    np.savez(root/'reference_layer_logp.npz',**{f'layer{l}':x for l,x in logps.items()});pd.DataFrame({'construct_id':mf.construct_id,**{f'layer{l}':s for l,s in scores.items()}}).to_csv(root/'evolutionary_scores.csv',index=False)
    grid=[dict(alpha=alpha,score_weight=w) for alpha in cfg['alphas'] for w in cfg['score_weights']];rows=[];choices=[];start=time.time()
    for k,f in enumerate(folds):
        tr=np.array(f['train']);te=np.array(f['test']);assert not set(groups[tr])&set(groups[te]);candidates=[]
        for sp in f['inner']:assert set(sp['train81']+sp['validation81'])==set(tr) and not set(groups[sp['train81']])&set(groups[sp['validation81']])
        for l,score in scores.items():
            path=root/'folds'/f'fold{k+1:03}'/f'layer{l}.json'
            if path.exists():r=json.loads(path.read_text())
            else:
                candidates_l=[]
                for index,spec in enumerate(grid):
                    vals=[]
                    for sp in f['inner']:
                        ti=np.array(sp['train81']);vi=np.array(sp['validation66']);q=predict(fit(onehot,score,Y,ti,'Hsu_ESM2_OneHot_Ridge',spec),onehot,score,vi);vals.append(obj(Y[vi],q,vi))
                    candidates_l.append(dict(index=index,spec=spec,metrics=np.mean(vals,axis=0).tolist()))
                best=max(candidates_l,key=lambda c:tuple(c['metrics']));q=predict(fit(onehot,score,Y,tr,'Hsu_ESM2_OneHot_Ridge',best['spec']),onehot,score,te);r=dict(layer=l,train=tr.tolist(),test=te.tolist(),candidates=candidates_l,selected=best,predictions=q.tolist());save(path,r)
            assert r['train']==tr.tolist() and r['test']==te.tolist();candidates.append(r)
            for i,q in zip(te,r['predictions']):
                row=dict(method=f'layer{l}',layer=l,construct_id=mf.iloc[i].construct_id,batch=mf.iloc[i].batch,double_repeat=len(json.loads(mf.iloc[i].repeat_position_set))>1,fold=k+1,S=float(S(Y[i:i+1])[0]),S_hat=float(S(np.array([q]))[0]));row.update({c+'_hat':q[j] for j,c in enumerate(['C295','C388','C871'])});rows.append(row)
        best=max(candidates,key=lambda r:(*r['selected']['metrics'],-r['layer']));choices.append(dict(fold=k+1,layer=best['layer'],selected=best['selected']))
        for i in te:
            row=next(r.copy() for r in rows if r['fold']==k+1 and r['layer']==best['layer'] and r['construct_id']==mf.iloc[i].construct_id);row['method']='inner_selected_layer';rows.append(row)
        print('FOLD',k+1,'/66',round(time.time()-start,1),'seconds',flush=True)
    df=pd.DataFrame(rows);df=df.sort_values(['method','S_hat','construct_id'],ascending=[True,False,True]);df['predicted_rank']=df.groupby('method').cumcount()+1;df['measured_rank']=df.groupby('method').S.rank(ascending=False,method='min').astype(int);df.to_csv(root/'oof_rankings.csv',index=False);md=[]
    for name,d in df.groupby('method'):
        assert len(d)==66
        for subset,e in [('all',d),('batch1',d[d.batch.eq('batch1')]),('batch2',d[d.batch.eq('batch2')]),('double_repeat',d[d.double_repeat])]:md.append(dict(method=name,subset=subset,**metric(e)))
    pd.DataFrame(md).to_csv(root/'metrics.csv',index=False);save(root/'inner_layer_selections.json',choices)
    original=pd.read_csv(inp/'oof_all_models.csv');original=original[original.model.eq('Hsu_ESM2_OneHot_Ridge_A')];joined=df[df.method.eq('layer12')].merge(original,on='construct_id',suffixes=('_new','_old'));err=float(np.max(np.abs(joined.S_hat_new-joined.S_hat_old)));assert len(joined)==66 and err<1e-7
    save(root/'VALIDATED.json',dict(folds=66,layers=12,oof_rows=len(df),last_layer_score_max_difference=maxerr,last_layer_OOF_max_difference=err,group_leakage_checked=True,main_model_pipeline_preserved=True,intermediate_readout='shared frozen final-layer normalization and LM head; diagnostic logit lens',scope='development-stage CV; no independent validation',elapsed_cv_seconds=time.time()-start));print(pd.DataFrame(md).query("subset=='all'").to_string(index=False));print('COMPLETE',flush=True)

if __name__=='__main__':main()
