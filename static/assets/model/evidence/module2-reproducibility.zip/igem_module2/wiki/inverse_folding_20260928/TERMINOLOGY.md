# Terminology ledger

| Term | Meaning |
|---|---|
| All-position sampling | All 493 positions mutable; not necessarily all replaced |
| TRM-only sampling | Only 36 configured recognition residues mutable |
| Non-TRM nomination | Post-sampling single-substitution proposal outside TRM |
| Exact consensus | Same replacement passes the rule in both models |
| Sampling frequency | Observed fraction of 10,000 sampled sequences |
| Editing endpoint | C295, C388 or C871 assay measurement, not protein numbering |
| PUF-ESM Specificity Ranker | Frozen ESM-2 score plus one-hot encoding and Ridge |
| Loop | PyDSSP structural assignment; not measured dynamics |
