# Figure plan and evidence map

Workflow: existing ORCA native rectangle/arrow layout, 960 CSS px target. Input structure branches to two design masks; both feed the two-model sampling stage. Fixed models, temperature and seed constrain that stage. Samples feed the AiCE-inspired screen, which feeds descriptive assay comparison. Solid arrows indicate data processing, not biological causation. All nodes and counts are observed analysis configuration/results; later binding experiments appear only in prose as proposals. No generative-image assets are used in the delivered workflow.

Data figures: non-TRM count comparison; frequencies for every nominated TRM substitution; selected within-batch assay contrasts; WT-background scores for all ten nominations. Inputs, hashes, scientific units and exclusions are recorded per figure. No new thresholds or statistical tests.

Primary evidence: research/inverse_folding_20260928/nontrm/validation.json, trm_only/validation.json, experimental_comparison/source_records.csv and construct_comparison.csv. Workflow typography and connectors were edited in Microsoft PowerPoint; exported PDF was rasterized at 1920 px. Data plots use the attached ORCA helper and the existing project style tokens.
