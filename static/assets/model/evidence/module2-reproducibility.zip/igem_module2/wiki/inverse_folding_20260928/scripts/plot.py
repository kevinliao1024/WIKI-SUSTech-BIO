from pathlib import Path
import csv, json, hashlib, argparse, shutil
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from orca_plot import Theme, export

ROOT=Path(__file__).resolve().parents[1]
def read(name):
    return list(csv.DictReader((ROOT/'data'/name).open(encoding='utf-8-sig')))
parser=argparse.ArgumentParser(); parser.add_argument('--output',type=Path); args=parser.parse_args()
OUTPUT=args.output or ROOT
OUTPUT.mkdir(parents=True,exist_ok=True)
style=OUTPUT/'orca-figure-style.json'
if OUTPUT.resolve()!=ROOT.resolve():
    if style.exists(): raise FileExistsError(style)
    shutil.copy2(ROOT/'orca-figure-style.json',style)
cfg=json.loads(style.read_text())
cfg['group_styles'].update({'LigandMPNN':{'color':'#2E267C','marker':'o'},'ProteinMPNN':{'color':'#27877F','marker':'s'}})
style.write_text(json.dumps(cfg,indent=2)+'\n')
theme=Theme(style)
provenance={'inputs':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/'data').glob('*.csv')},'exclusions':[],'statistics':'Descriptive only; no inference or fabricated uncertainty','sampling_n':10000,'frequency_unit':'proportion of sampled sequences','seed':111}
def save(fig,slug,caption,alt,rows):
    out=OUTPUT/'figures'/slug
    export(fig,out,theme,caption=caption,alt_text=alt,provenance=provenance)
    with (out/'plotted-data.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    plt.close(fig)

with theme.context():
    fig,ax=theme.figure(height=5.5)
    rows=[{'screen':'Global only','positions':81,'substitutions':81,'consensus':17}, {'screen':'Structure completed','positions':125,'substitutions':128,'consensus':46}]
    x=np.arange(2)
    for i,(key,label,color) in enumerate([('positions','Positions','#27877F'),('substitutions','Substitutions','#2E267C'),('consensus','Exact consensus','#E89B3C')]):
        bars=ax.bar(x+(i-1)*.24,[r[key] for r in rows],.22,color=color,label=label)
        ax.bar_label(bars,padding=4,fontsize=18)
    ax.set(xticks=x,xticklabels=[r['screen'] for r in rows],ylabel='Non-TRM nominations (count)',ylim=(0,155))
    ax.legend(loc='upper left',ncols=1,fontsize=16)
    save(fig,'nontrm_screen','Archived all-position sampling, 10,000 sequences per model. The global-only screen used β = 0.8. Completing PyDSSP loop labels enabled the existing γ = 0.5 route. Counts are distinct positions, distinct substitutions and same-substitution dual-model consensus. The 81 previous substitutions were retained; 47 were added. These are computational nominations, not experimentally validated improvements.','Non-TRM substitutions increase from 81 to 128 and exact consensus from 17 to 46 after completion of structural labels.',rows)

    rows=read('trm_single_nominations.csv'); fig,ax=theme.figure(height=7.0)
    y=np.arange(len(rows))
    for model,label,offset in [('ligand_mpnn','LigandMPNN',-.14),('protein_mpnn','ProteinMPNN',.14)]:
        s=theme.style(label)
        ax.scatter([100*float(r[model+'_tested_alt_frequency']) for r in rows],y+offset,label=label,color=s['color'],marker=s['marker'],s=90)
    ax.axvline(80,color=theme.c['muted'],ls='--',lw=1.5)
    ax.set(yticks=y,yticklabels=[r['mutation'] for r in rows],xlabel='TRM-only sampling frequency (%)',xlim=(-2,104))
    ax.invert_yaxis(); ax.legend(loc='lower left')
    save(fig,'trm_frequencies','All 10 nominated TRM substitutions are shown. Each model generated 10,000 sequences with 36 TRM residues mutable and 457 other residues fixed. The dashed line marks β = 0.8; nomination also required alternative frequency greater than WT frequency. All 36 TRM residues were assigned helix, so the flexible-loop route was inapplicable. LigandMPNN nominated 10 substitutions, ProteinMPNN zero, and exact consensus was zero. Frequencies do not measure RNA affinity.','LigandMPNN exceeds 80 percent for ten substitutions; ProteinMPNN remains below 80 percent for all ten.',rows)

    source=read('source_records.csv'); constructs=read('construct_comparison.csv')
    selected=[('Y37R','Y37R',2),('E184Q','E184Q',1),('Y145N;Y253N','Y145N + Y253N',1),('S288G;Y289V','S288G + Y289V',1),('E256R','E256R',1)]
    fig,ax=theme.figure(height=7)
    plot=[]
    for i,(mutation,label,batch) in enumerate(selected):
        row=next(r for r in constructs if r['mutations']==mutation and int(r['batch'])==batch)
        controls=[r for r in constructs if r['control']=='True' and int(r['batch'])==batch]
        for j,(site,color,marker) in enumerate([('C295','#27877F','s'),('C388','#2E267C','o'),('C871','#E89B3C','D')]):
            for k,ctrl in enumerate(controls):
                delta=100*(float(row[site+'_mean'])-float(ctrl[site+'_mean']))
                ax.scatter(delta,i+(j-1)*.19+(k-.5)*.045,color=color,marker=marker,s=75,label=site if i==0 and k==0 else None)
                plot.append({'mutation':mutation,'batch':batch,'group':row['group'],'source_rows':row['rows'],'control_group':ctrl['group'],'control_rows':ctrl['rows'],'site':site,'delta_percentage_points':delta})
    ax.axvline(0,color=theme.c['muted'],lw=1.5)
    ax.set(yticks=range(5),yticklabels=[r[1] for r in selected],xlabel='Editing change vs batch control (pp)',xlim=(-65,20)); ax.invert_yaxis()
    ax.legend(ncols=3,loc='upper center',bbox_to_anchor=(.5,1.12))
    save(fig,'assay_comparison','Selected descriptive cases: both nominated substitutions tested as single mutants (Y37R and E184Q), plus three previously discussed experimental examples. Each construct and control has two spreadsheet records of unknown replicate type. Points show differences of record means, not paired replicate effects. Y37R is compared separately with both batch-2 controls; other cases use the batch-1 control. No significance tests, error intervals or cross-batch pooled control are used. Nondetection flags remain in the complete source table. This selected panel does not estimate full-cohort prediction accuracy.','Two strongly sampled single mutants reduce target-site editing; several experimentally favourable bystander profiles are rarely sampled.',plot)

    rows=read('WT_background_single_mutant_scores.csv')[1:]; fig,ax=theme.figure(height=7)
    y=np.arange(len(rows))
    for model,label,offset in [('ligand_mpnn','LigandMPNN',-.13),('protein_mpnn','ProteinMPNN',.13)]:
        s=theme.style(label); ax.scatter([float(r[model+'_delta_mean_log_probability_vs_WT']) for r in rows],y+offset,label=label,color=s['color'],marker=s['marker'],s=85)
    ax.axvline(0,color=theme.c['muted'],lw=1.5); ax.set(yticks=y,yticklabels=[r['mutation'] for r in rows],xlabel='WT-background Δ mean log probability'); ax.invert_yaxis(); ax.legend(loc='lower right',fontsize=16)
    save(fig,'single_scores','Each nominated substitution was placed separately on the WT sequence and scored using the official model score implementation. Values are differences from WT in mean log probability over 36 TRM positions, averaged across eight shared decoding orders (seed 111). Positive values indicate model preference under this protocol, not binding improvement. E292Q has negative values in both models despite its high LigandMPNN sampling frequency. This supplementary diagnostic did not change the nomination threshold or candidate set.','E292Q loses its apparent advantage when evaluated alone on the WT background.',rows)
