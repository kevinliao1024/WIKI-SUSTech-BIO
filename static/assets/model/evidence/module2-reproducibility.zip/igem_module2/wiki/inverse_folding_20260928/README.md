# Current inverse-folding results

[Part II manuscript](Part2_inverse_folding_EN.md) · [APA references](APA_references.md) · [Workflow PPTX](figures/workflow/figure.pptx)

Data plots are native Matplotlib outputs using the supplied ORCA helper; the workflow was edited in PowerPoint with native shapes and connectors. No image-generated workflow is included in this release.

To recreate data plots, run `python scripts/plot.py --output /path/to/new-output` with NumPy and Matplotlib. The exporter refuses to overwrite outputs. Matplotlib 3.11.2, NumPy 2.3.5 and Python 3.12.14 were used. Futura was available; figures record actual fonts. Do not install or redistribute commercial fonts. Source tables stay read-only. The workflow is edited using `figures/workflow/figure.pptx`.

Figure 9 compares a historical global-only screen with completed structural screening. Figures 10 and 12 include all ten TRM nominations. Figure 11 is an explicitly selected descriptive panel, not a validation accuracy estimate. All underlying source records remain available in the research comparison directory.
