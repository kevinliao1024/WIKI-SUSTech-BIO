## Part II. Structure-conditioned PUF design and experimental comparison

### Background and objective

PUF recognition residues help specify RNA binding, whereas other residues support the surrounding protein scaffold (Wang et al., 2002; Cheong & Hall, 2006). We examined both regions to nominate substitutions for the next experimental cycle. The objective was to identify structure-compatible candidates and compare their sequence preferences with measured editing profiles.

We followed the single-substitution screening logic of AiCE, which combines inverse-folding preferences with structural constraints (Fei et al., 2025). Our implementation is an **AiCE-inspired screen using PyDSSP three-state assignments**, rather than a complete reproduction of AiCE. We did not implement its multi-mutation evolutionary coupling analysis or establish increased RNA affinity.

### Models and two design spaces

ProteinMPNN conditions sequence generation on protein backbone geometry (Dauparas et al., 2022). LigandMPNN additionally represents nonprotein atomic context, including nucleotides (Dauparas et al., 2025). Here, LigandMPNN received the fixed RNA coordinates, whereas ProteinMPNN provided a protein-backbone comparison. Neither model was trained on our editing measurements.

Both analyses used the same 493-residue PUF reference and the 17-nucleotide RNA sequence `ACAUGGAGGACGUGCGC`. Protein substitutions use one-based residue numbering. C295, C388 and C871 identify assay endpoints; they are not protein residue numbers. RNA endpoint C388 maps to nucleotide 15 of this structural fragment.

![Two inverse-folding design spaces and their comparison with measured constructs](figures/workflow/figure@2x.png)

*Figure 8. All-position and TRM-only design with ProteinMPNN and LigandMPNN, using 10,000 sequences per model and design space, followed by screening and experimental comparison.*

| Analysis | Mutable protein positions | Fixed protein positions | Sampling source | Reported screen |
|---|---:|---:|---|---|
| All-position sampling | 493 | 0 | Archived 10,000 sequences per model | Non-TRM substitutions after excluding 36 recognition positions |
| TRM-only sampling | 36 | 457 | Newly generated 10,000 sequences per model | All 36 recognition positions; all amino-acid substitutions permitted |

“All-position” means that every residue was eligible for replacement; individual sequences need not replace every residue. The archived samples did not preserve TRMs during generation. Their non-TRM single-mutant exports subsequently restored the WT background, including all recognition residues.

For each position, each model nominated its most frequent alternative when its frequency exceeded the WT frequency. The alternative also had to reach 0.8 globally, or 0.5 at a PyDSSP loop position. Exact dual-model consensus required both models to pass their applicable threshold for the **same replacement**. These rules, including β = 0.8 and γ = 0.5, were unchanged.

### All-position sampling expands the non-TRM candidate set

Completing the structural screen yielded **128 non-TRM substitutions at 125 positions**, including **46 exact dual-model consensus substitutions**. The previous global-only calculation yielded 81 substitutions at 81 positions, including 17 consensus substitutions. All 81 previous substitutions were retained, and 47 substitutions at 44 additional positions were added. Twenty-nine substitutions newly obtained consensus support; some were already nominated by one model.

![Non-TRM nomination counts before and after structural screening](figures/nontrm_screen/figure@2x.png)

*Figure 9. Non-TRM nominations before and after completing structural screening. Exact consensus requires both models to support the same substitution.*

The earlier script tested PyDSSP loop assignments against `C`, although the installed three-state representation uses `-`, `H` and `E`. The corrected annotation identified 129 loop, 360 helical and four strand residues. A loop assignment is a structural proxy, not an experimental measurement of flexibility. Positions 177, 249 and 285 retained different model-supported substitutions and were excluded from exact consensus.

We also corrected substitution identities in the earlier exports. The supporting model frequencies nominate **N12G, M433L and V457I**, rather than N12S, M433A and V457L. Candidate tables now identify the supporting model and its exact replacement. All 128 single-mutant sequences were checked against the reference, with TRM positions unchanged.

### TRM-only generation produces model-specific nominations

The new TRM-only runs each completed 10,000 samples, with all 457 non-TRM residues verified unchanged. LigandMPNN produced 9,961 unique sequences and averaged 21.53 TRM substitutions per sample. ProteinMPNN produced 10,000 unique sequences and averaged 29.25 substitutions. Thus, sampled sequences usually combined many recognition changes.

All 36 TRM residues were assigned helix, so the 0.5 loop route did not apply. LigandMPNN nominated **10 substitutions**, whereas ProteinMPNN nominated **none**. Consequently, the TRM-only screen had **zero exact dual-model consensus substitutions**.

![Sampling frequencies for all ten nominated TRM substitutions](figures/trm_frequencies/figure@2x.png)

*Figure 10. Frequencies of ten nominated substitutions in 10,000 TRM-only samples per model. The dashed line marks the 80% threshold; frequencies do not measure affinity.*

| Substitution | LigandMPNN frequency | ProteinMPNN frequency |
|---|---:|---:|
| Y37R | 99.40% | 18.08% |
| E40Q | 84.91% | 0.32% |
| S72C | 82.42% | 18.22% |
| R109L | 85.93% | 12.97% |
| E148Q | 90.06% | 40.09% |
| S180C | 99.78% | 22.96% |
| E184Q | 98.22% | 47.09% |
| E256Q | 94.50% | 49.12% |
| E292Q | 93.09% | 51.06% |
| R400Q | 87.25% | 55.74% |

The difference between models is compatible with their different conditioning and pretrained parameters. It does not isolate RNA context as the causal explanation, because the comparison changes the model as well as its inputs.

### Experimental overlap, similarity and disagreement

The two supplied workbooks contained 168 records, grouped into 81 mutant constructs and three control groups. Every group had two records, but their biological or technical replicate status was unspecified. Sequence mapping identified 121 distinct substitutions across 31 positions, all within the configured TRM region.

Accordingly, **none of the 128 non-TRM nominations has an exact substitution or position match in these experiments**. This is an untested design space, rather than evidence of experimental contradiction. Within the TRM nominations, **Y37R, E184Q and S72C** occurred among measured substitutions. Y37R and E184Q were tested individually; S72C appeared in multi-mutant constructs, preventing attribution of their outcomes to S72C alone.

These three substitutions represent 3/10 nominated substitutions and 3/121 measured distinct substitutions. These descriptive coverage fractions are not predictive accuracy. The full 81-construct table separately reports changed-residue matches, whole-TRM motif matches and exact full-sequence matches. A motif match does not establish identity of the remaining sequence.

![Editing changes for nominated single mutants and selected experimental examples](figures/assay_comparison/figure@2x.png)

*Figure 11. Selected editing changes from same-batch controls; each mean uses two records of unspecified replicate type. Y37R is compared separately with both batch-2 controls. No significance testing.*


Across all 81 measured constructs, at least one TRM-only sample contained every specified substitution for 23 constructs with LigandMPNN and 35 with ProteinMPNN. Requiring the complete affected TRM triplets reduced coverage to 13 and 20 constructs, respectively. Neither model generated an exact full-length match to any measured construct. These coverage counts use any observed occurrence, not the 80% nomination threshold, and do not quantify editing accuracy.

| Match definition | LigandMPNN construct coverage | ProteinMPNN construct coverage |
|---|---:|---:|
| All specified substitutions present; other residues unconstrained | 23/81 (28.4%) | 35/81 (43.2%) |
| All affected TRM triplets match; other triplets unconstrained | 13/81 (16.0%) | 20/81 (24.7%) |
| Entire 493-residue experimental sequence matches | 0/81 | 0/81 |

**High sampling preference did not consistently indicate higher target editing.** Y37R occurred in 99.40% of LigandMPNN samples, but measured C388 was 60.39%. The two batch-2 controls measured 67.64% and 66.53%. E184Q occurred in 98.22% of samples, but its C388 mean was 59.12%, compared with 72.56% for the batch-1 control. These discrepancies challenge a direct interpretation of sampling frequency as target-editing benefit. They do not independently establish weaker binding, which was not measured.

**Several useful experimental profiles were rarely recovered by the sampler.** Y145N + Y253N increased C388 by 7.77 percentage points while reducing C295 and C871 by 13.15 and 34.90 points. P8-GVE, carrying S288G + Y289V, reduced C388 by 6.70 points but reduced C871 by 57.27 points. The joint S288G + Y289V substitution set was absent from both TRM-only sample sets. Zero observations mean absence from 10,000 samples, rather than biological impossibility.

**Position-level similarity can conceal different substitutions.** The model nominated E256Q, whereas the measured P7-SYVIRR construct changed E256R; its adjacent position 257 was already arginine. E256R increased C388 by 6.82 points and reduced C871 by 39.44 points, while increasing C295 by 12.30 points. This mixed profile cannot validate the untested E256Q substitution.

The spreadsheet comparison preserves nondetection flags alongside the recorded values, including displayed zeros. The existing ESM Ranker training cohort instead treats invalid or missing assay labels as missing. Its 66 complete-score constructs and frozen cross-validation metrics remain unchanged. The two data views therefore answer different questions and must not be merged by silently converting nondetection to valid training labels.

### WT-background scoring and interpretation

We additionally scored each nominated TRM substitution individually on the WT background using the official model scoring implementation. Scores averaged eight shared decoding orders and measured mean log probability over the 36 TRM positions. This diagnostic did not modify the nomination thresholds or remove candidates.

![Single-mutant scores relative to WT under both inverse-folding models](figures/single_scores/figure@2x.png)

*Figure 12. Change in mean TRM log probability versus WT, averaged over eight decoding orders. Positive values indicate model preference, not measured binding improvement.*

For E292Q, the changes were −0.0756 for LigandMPNN and −0.0200 for ProteinMPNN. This mismatch shows why a marginal frequency from multi-mutant samples cannot be assigned directly to a WT single mutant. The other nine candidates increased both scores, but these model-based checks remain distinct from experimental validation.

## Next Design–Build–Test–Learn cycle

The next experiments should separate scaffold improvement, recognition changes and editing specificity. Non-TRM candidates should first be added individually to characterized TRM backgrounds, with unchanged parental controls. TRM candidates should be tested individually before evaluating combinations, including exact alternatives at shared positions such as E256Q and E256R.

Direct binding assays should compare the fixed target RNA with defined alternative RNAs. Matched editing experiments should measure all three endpoints, together with expression and protein integrity where feasible. Candidate selection and evaluation criteria should be recorded before collecting the next batch. These experiments would distinguish binding effects from changes in expression, catalytic positioning or cellular context.

The existing **PUF-ESM Specificity Ranker** can provide a separate assay-informed prioritization layer, following the integration of evolutionary and labelled data described by Hsu et al. (2022). Its frozen ESM-2 score, one-hot encoding and Ridge regressors differ from the structure-conditioned MPNN screen. Its existing grouped cross-validation remains developmental evidence; candidates from these new design spaces require prospective assessment, particularly at previously untested non-TRM positions.

## Data, figures and reproducibility


The main project repository is [pdx12320/igem_module2](https://github.com/pdx12320/igem_module2). The prepared repository update brings together the assay-informed ranker and the structure-conditioned design results. The earlier [PUF_alphafold repository](https://github.com/pdx12320/PUF_alphafold) remains the historical source for the archived structural inputs and all-position samples.

- [Current figures, plotted data and ORCA plotting script](https://github.com/pdx12320/igem_module2/tree/main/wiki/inverse_folding_20260928)
- [Non-TRM reanalysis, 128 single mutants and structural validation](https://github.com/pdx12320/igem_module2/tree/main/research/inverse_folding_20260928/nontrm)
- [TRM-only samples, ten nominations and reproducible sampling code](https://github.com/pdx12320/igem_module2/tree/main/research/inverse_folding_20260928/trm_only)
- [Complete experimental comparison and source-row audit](https://github.com/pdx12320/igem_module2/tree/main/research/inverse_folding_20260928/experimental_comparison)
- [Reusable PUF-ESM Specificity Ranker](https://github.com/pdx12320/igem_module2/tree/main/puf_reuse)
- [Upstream LigandMPNN implementation](https://github.com/dauparas/LigandMPNN)

Reproduction records retain seeds, masks, model versions, input checksums and validation results. The updated figures and prose do not retrain the ESM Ranker or introduce new wet-lab measurements.

## References

Cheong, C. G., & Hall, T. M. T. (2006). Engineering RNA sequence specificity of Pumilio repeats. *Proceedings of the National Academy of Sciences, 103*(37), 13635–13639. https://doi.org/10.1073/pnas.0606294103

Dauparas, J., Anishchenko, I., Bennett, N., Bai, H., Ragotte, R. J., Milles, L. F., Wicky, B. I. M., Courbet, A., de Haas, R. J., Bethel, N., Leung, P. J. Y., Huddy, T. F., Pellock, S., Tischer, D., Chan, F., Koepnick, B., Nguyen, H., Kang, A., Sankaran, B., … Baker, D. (2022). Robust deep learning–based protein sequence design using ProteinMPNN. *Science, 378*(6615), 49–56. https://doi.org/10.1126/science.add2187

Dauparas, J., Lee, G. R., Pecoraro, R., An, L., Anishchenko, I., Glasscock, C., & Baker, D. (2025). Atomic context-conditioned protein sequence design using LigandMPNN. *Nature Methods, 22*(4), 717–723. https://doi.org/10.1038/s41592-025-02626-1

Fei, H., Li, Y., Liu, Y., Wei, J., Chen, A., & Gao, C. (2025). Advancing protein evolution with inverse folding models integrating structural and evolutionary constraints. *Cell, 188*(17), 4674–4692.e19. https://doi.org/10.1016/j.cell.2025.06.014

Hsu, C., Nisonoff, H., Fannjiang, C., & Listgarten, J. (2022). Learning protein fitness models from evolutionary and assay-labeled data. *Nature Biotechnology, 40*(7), 1114–1122. https://doi.org/10.1038/s41587-021-01146-5

Lin, Z., Akin, H., Rao, R., Hie, B., Zhu, Z., Lu, W., Smetanin, N., Verkuil, R., Kabeli, O., Shmueli, Y., dos Santos Costa, A., Fazel-Zarandi, M., Sercu, T., Candido, S., & Rives, A. (2023). Evolutionary-scale prediction of atomic-level protein structure with a language model. *Science, 379*(6637), 1123–1130. https://doi.org/10.1126/science.ade2574

Wang, X., McLachlan, J., Zamore, P. D., & Hall, T. M. (2002). Modular recognition of RNA by a human Pumilio-homology domain. *Cell, 110*(4), 501–512. https://doi.org/10.1016/S0092-8674(02)00873-5
