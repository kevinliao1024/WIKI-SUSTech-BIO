# 本次第二部分更新

流程图按用户提供的 ORCA skill 方法，在 Microsoft PowerPoint 中以原生矩形、文字与连接线编辑；采用参考图同款版式。交付 PPTX、PDF 和 1920 像素 PNG。四张结果图使用 ORCA Python helper，附原始绘图表、脚本、图注、字体及版本记录。

正文已覆盖背景、模型、全位点采样、TRM-only 采样、实验一致与矛盾、后续分析、APA 引用及仓库复用地址。两个原有英文 Wiki 页均更新了第二部分。

- 全位点样本经补全结构筛选：125 个位置、128 种非 TRM 替换、46 种精确双模型共识。
- TRM-only：两个模型各新生成 10,000 条，固定 457 个非 TRM 位点。LigandMPNN 提名 10 种，ProteinMPNN 为 0，共识为 0。
- 实验中的 121 种替换全部属于 TRM，不能用于验证非 TRM 候选。TRM 提名中 Y37R、E184Q、S72C 有替换交集，后者仅见于多突变构建。
- 强采样偏好不等于更高 C388 编辑，更不等于已经证实的 RNA 亲和力提高。
- E292Q 在 WT 单突变背景的两模型评分都低于 WT；候选集合和原阈值仍完整保留。

主仓库：https://github.com/pdx12320/igem_module2 。新结构分析包位于 research/inverse_folding_20260928；当前图文位于 wiki/inverse_folding_20260928。现有 ESM Ranker 权重、训练标签、划分与冻结结果没有更改。
