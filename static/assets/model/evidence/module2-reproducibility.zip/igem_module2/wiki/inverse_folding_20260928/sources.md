# Sources and limitations

AiCE: Fei et al. (2025), https://doi.org/10.1016/j.cell.2025.06.014. Supplied PDF, methods supporting single-mutation structural/frequency screening. This implementation uses PyDSSP three-state loop proxies and does not reproduce AiCE multi-mutation evolutionary coupling.

ProteinMPNN: Dauparas et al. (2022), https://doi.org/10.1126/science.add2187, original paper and upstream implementation. Supports backbone-conditioned sequence design; does not validate current PUF editing.

LigandMPNN: Dauparas et al. (2025), https://doi.org/10.1038/s41592-025-02626-1, abstract and model architecture. Supports nonprotein atomic conditioning; current PUF binding remains unmeasured.

Assay-informed feature integration: Hsu et al. (2022), https://doi.org/10.1038/s41587-021-01146-5. Existing PUF-ESM adaptation remains unchanged. ESM-2 source: Lin et al. (2023), https://doi.org/10.1126/science.ade2574.

All seven reference metadata records were checked against DOI/Crossref records. Citations are in APA_references.md. Numerical claims come from the local analysis tables, not from literature performance claims. Workbook hashes, sheet names and row coordinates accompany source_records.csv; raw spreadsheets are not redistributed here.
