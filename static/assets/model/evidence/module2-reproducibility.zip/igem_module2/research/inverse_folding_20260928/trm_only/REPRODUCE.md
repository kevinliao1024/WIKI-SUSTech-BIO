# Reproduce the TRM-only sampling

The bundle contains the required inference source from LigandMPNN commit 26ec57ac976ade5379920dbd43c7f97a91cf82de and its MIT license. Official model weights are not duplicated in the bundle. Download these from the official distribution, then compare SHA256 with provenance.json:

- https://files.ipd.uw.edu/pub/ligandmpnn/ligandmpnn_v_32_010_25.pt
- https://files.ipd.uw.edu/pub/ligandmpnn/proteinmpnn_v_48_020.pt

Use a dedicated Python 3.12 environment with requirements.txt. No system-wide install is needed. Run from the bundle directory:

```bash
python scripts/reproduce_sampling.py --weights /path/to/weights --out /path/to/NEW_sampling --python /path/to/env/bin/python
```

This launches two sequential 10,000-sequence sampling jobs. It refuses an existing output directory. CPU threads=1; seed=111; temperature=0.5; batch size=50; 200 batches. The wrapper only changes device/thread selection, restores the removed NumPy int alias, adds progress logging and omits redundant backbone exports.

For the analysis script, --repo must point to the original PUF_alphafold checkout, --previous to the earlier nontrm_aice_structural result directory, and --experiments to nontrm_vs_two_batches. Snapshots of the needed structure annotations and experimental construct summary are in inputs/; these can be placed in new directories with their original filenames, structure_annotations.csv and construct_comparison.csv.

```bash
python scripts/analyse_trm.py --sampling-dir /path/to/NEW_sampling --repo /path/to/PUF_alphafold --previous /path/to/nontrm_aice_structural --experiments /path/to/nontrm_vs_two_batches --out /path/to/NEW_results
python scripts/score_candidates.py --mpnn LigandMPNN --weights /path/to/weights --pdb inputs/complex.pdb --config inputs/design_config.json --results /path/to/NEW_results
python scripts/compare_previous.py --repo /path/to/PUF_alphafold --results /path/to/NEW_results
```

The original model parameter binaries and intermediate PyTorch statistics remain in the task working directory. All 20,000 generated sequences and the reported CSV statistics are included in this bundle.
