import argparse,csv,gzip,json,hashlib,platform
from pathlib import Path
import numpy as np
p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--reuse',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
a.out.mkdir(parents=True,exist_ok=False)
b=a.repo/'research/aice_mpnn_20260922';cfg=json.loads((b/'inputs/design_config.json').read_text());ref=json.loads((a.reuse/'wiki/ablation_experiment/inputs/reference.json').read_text())['reference'];AA='ACDEFGHIKLMNPQRSTVWY';L=len(ref);trm=set(cfg['specificity_positions_0based']);assert L==493 and len(trm)==36
old={int(r['pos_1based']):r for r in csv.DictReader((b/'results/aice_single_ranked.csv').open())}
def write(name,rows):
 with (a.out/name).open('w') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
freqs={};summary={};checks=[]
for model in ['proteinmpnn','ligandmpnn']:
 path=b/f'results/mpnn_samples_{model}.fa.gz';records=[];header=None;seq=[]
 with gzip.open(path,'rt') as f:
  for ln in f:
   if ln.startswith('>'):
    if header is not None: records.append((header,''.join(seq)))
    header=ln.strip();seq=[]
   else:seq.append(ln.strip())
  records.append((header,''.join(seq)))
 assert len(records)==10001 and records[0][1]==ref
 samples=records[1:];assert all(len(s)==L and not set(s)-set(AA) for _,s in samples)
 assert len({h for h,s in samples})==10000
 arr=np.frombuffer(''.join(s for _,s in samples).encode(),dtype='S1').reshape(10000,L)
 freq=np.stack([(arr==c.encode()).mean(0) for c in AA],axis=1);freqs[model]=freq
 assert np.allclose(freq.sum(1),1)
 for i in range(L):
  alt=freq[i].copy();alt[AA.index(ref[i])]=-1;k=alt.argmax()
  assert abs(float(old[i+1][model+'_f_max'])-alt[k])<1e-8
  assert old[i+1][model+'_mut']==AA[k]
  assert abs(float(old[i+1][model+'_f_wt'])-freq[i,AA.index(ref[i])])<1e-8
 summary[model]={'sample_count':10000,'unique_sequences':len({s for _,s in samples}),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
# Audit observed training variation, without loading executable model serialization.
training=list(csv.DictReader((a.reuse/'wiki/ablation_experiment/inputs/construct_manifest.csv').open()))
coverage=np.zeros(L,int)
for r in training:
 s=r['puf_sequence']
 if len(s)==L and not set(s)-set(AA):coverage+=np.array([x!=y for x,y in zip(ref,s)])
rows=[];candidates=[]
for i in range(L):
 r={'pos_1based':i+1,'wt':ref[i],'is_trm':i in trm,'training_mutated_constructs':int(coverage[i]),'archived_flexible':old[i+1]['in_flexible']};nom=[]
 for model,freq in freqs.items():
  alt=freq[i].copy();alt[AA.index(ref[i])]=-1;k=alt.argmax();fm=float(alt[k]);fw=float(freq[i,AA.index(ref[i])]);passed=fm>fw and fm>=.8 and i not in trm
  r.update({model+'_mutation':f'{ref[i]}{i+1}{AA[k]}',model+'_f_alt':fm,model+'_f_wt':fw,model+'_pass_global':passed})
  if passed:nom.append((model,AA[k]))
 r['exact_consensus']=len(nom)==2 and nom[0][1]==nom[1][1];r['nomination_count']=len(nom);rows.append(r)
 for aa in sorted({aa for _,aa in nom}):
  supporting=[m for m,x in nom if x==aa]
  candidates.append({'mutation':f'{ref[i]}{i+1}{aa}','pos_1based':i+1,'wt':ref[i],'alt':aa,'supporting_models':';'.join(supporting),'exact_consensus':len(supporting)==2,'proteinmpnn_f_alt':freqs['proteinmpnn'][i,AA.index(aa)],'ligandmpnn_f_alt':freqs['ligandmpnn'][i,AA.index(aa)],'training_mutated_constructs':int(coverage[i]),'screen':'global_beta_0.8_existing_labels'})
write('all_positions.csv',rows);write('nontrm_candidates.csv',candidates);write('exact_consensus.csv',[r for r in candidates if r['exact_consensus']])
with (a.out/'single_mutants.fasta').open('w') as f:
 f.write('>WT\n'+ref+'\n')
 for r in candidates:
  i=r['pos_1based']-1;s=ref[:i]+r['alt']+ref[i+1:];assert sum(x!=y for x,y in zip(s,ref))==1 and all(s[j]==ref[j] for j in trm);f.write('>'+r['mutation']+'\n'+s+'\n')
summary.update({'status':'baseline_reanalysis_only_pending_DSSP_approval','positions':L,'excluded_trm_positions':len(trm),'candidate_positions':len({r['pos_1based'] for r in candidates}),'candidate_substitutions':len(candidates),'exact_consensus':sum(r['exact_consensus'] for r in candidates),'all_archived_frequencies_match':True,'candidate_positions_with_training_variation':int(sum(coverage[i-1]>0 for i in {r['pos_1based'] for r in candidates})),'python':platform.python_version(),'numpy':np.__version__})
(a.out/'validation.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary,indent=2))
