"""Annotate WT-background single substitutions with official model.score likelihoods.
Does not change AiCE nominations or estimate binding energy.
"""
import argparse,sys,json,csv,copy
from pathlib import Path
import numpy as np,torch
p=argparse.ArgumentParser();p.add_argument('--mpnn',type=Path,required=True);p.add_argument('--weights',type=Path,required=True);p.add_argument('--pdb',type=Path,required=True);p.add_argument('--config',type=Path,required=True);p.add_argument('--results',type=Path,required=True);a=p.parse_args();sys.path.insert(0,str(a.mpnn.resolve()))
from data_utils import parse_PDB,featurize,restype_str_to_int
from model_utils import ProteinMPNN
torch.set_num_threads(1);torch.manual_seed(111);pos=json.loads(a.config.read_text())['specificity_positions_0based'];names=[];seqs=[]
for ln in (a.results/'single_mutant_nominations.fasta').read_text().splitlines():
 if ln.startswith('>'):names.append(ln[1:])
 else:seqs.append(ln)
assert len(names)==len(seqs)
protein,*_=parse_PDB(str(a.pdb),device='cpu',parse_all_atoms=False);mask=torch.zeros(493);mask[pos]=1;protein['chain_mask']=mask
orders=torch.randn((8,493));rows={name:{'mutation':name} for name in names}
for m,ckptname in [('ligand_mpnn','ligandmpnn_v_32_010_25.pt'),('protein_mpnn','proteinmpnn_v_48_020.pt')]:
 ck=torch.load(a.weights/ckptname,map_location='cpu',weights_only=True);atoms=ck['atom_context_num'] if m=='ligand_mpnn' else 1
 model=ProteinMPNN(node_features=128,edge_features=128,hidden_dim=128,num_encoder_layers=3,num_decoder_layers=3,k_neighbors=ck['num_edges'],device='cpu',atom_context_num=atoms,model_type=m,ligand_mpnn_use_side_chain_context=0);model.load_state_dict(ck['model_state_dict']);model.eval()
 f=featurize(protein,cutoff_for_score=8.,use_atom_context=True,number_of_ligand_atoms=atoms,model_type=m);f.update(batch_size=8,randn=orders,symmetry_residues=[[]]);scoremask=(f['mask']*f['chain_mask'])[0].bool();assert int(scoremask.sum())==36
 with torch.no_grad():
  for name,seq in zip(names,seqs):
   f['S']=torch.tensor([[restype_str_to_int[c] for c in seq]])
   out=model.score(f,use_sequence=True);lp=out['log_probs'].gather(-1,f['S'].repeat(8,1).unsqueeze(-1)).squeeze(-1)
   val=lp[:,scoremask].mean(1).numpy();rows[name][m+'_mean_log_probability_TRM']=float(val.mean());rows[name][m+'_confidence_TRM']=float(np.exp(val.mean()))
   if m=='ligand_mpnn':
    sm=scoremask&f['mask_XY'][0].bool();rows[name]['RNA_proximal_TRM_count']=int(sm.sum());rows[name]['ligand_mpnn_mean_log_probability_RNA_proximal_TRM']=float(lp[:,sm].mean())
 for name in names:rows[name][m+'_delta_mean_log_probability_vs_WT']=rows[name][m+'_mean_log_probability_TRM']-rows['WT'][m+'_mean_log_probability_TRM']
with (a.results/'WT_background_single_mutant_scores.csv').open('x',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows['WT']));w.writeheader();w.writerows(rows.values())
(a.results/'score_protocol.json').write_text(json.dumps({'method':'Official autoregressive model.score; use_sequence=True','decoding_orders':8,'same_random_orders_for_every_sequence':True,'seed':111,'mask_positions':36,'aggregation':'mean log probability across 36 TRM positions and 8 orders; exp(mean log probability) reported as confidence','changes_nomination_thresholds':False,'binding_affinity_prediction':False,'RNA_context_atoms':int(protein['Y_m'].sum())},indent=2))
print('Scored',len(names),'WT-background sequences; not binding affinities')
