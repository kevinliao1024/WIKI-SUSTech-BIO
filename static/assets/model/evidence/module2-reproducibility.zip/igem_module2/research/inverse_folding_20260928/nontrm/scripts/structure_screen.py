import argparse,csv,json,hashlib,importlib.metadata,platform
from pathlib import Path
import numpy as np
import pydssp
from Bio.PDB import PDBParser
from Bio.SeqUtils import seq1
p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--baseline',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=False)
b=a.repo/'research/aice_mpnn_20260922';pdb=b/'inputs/complex.pdb';cfg=json.loads((b/'inputs/design_config.json').read_text());model=PDBParser(QUIET=True).get_structure('PUF',str(pdb))[0];res=list(model['A'].get_residues());assert len(res)==493
assert all(r.id==(' ',i+1,' ') for i,r in enumerate(res));ref=''.join(seq1(r.resname) for r in res)
old=list(csv.DictReader((a.baseline/'all_positions.csv').open()));assert ref==''.join(r['wt'] for r in old)
coords=np.array([[r[k].coord for k in ['N','CA','C','O']] for r in res],dtype=np.float64);assert coords.shape==(493,4,3) and np.isfinite(coords).all()
ss=pydssp.assign(coords,out_type='c3');idx=pydssp.assign(coords,out_type='index');assert set(ss)<=set('-HE');assert np.array_equal(ss=='-',idx==0);flex=idx==0
rna=[r for r in model['R']];assert len(rna)==17
heavy=np.array([atom.coord for r in rna for atom in r if atom.element not in ['H','D']]);target=np.array([atom.coord for atom in rna[14] if atom.element not in ['H','D']]);assert rna[14].resname.strip()=='C'
struct=[];positions=[];cand=[];baseline_muts={r['mutation'] for r in csv.DictReader((a.baseline/'nontrm_candidates.csv').open())}
for i,(r,o) in enumerate(zip(res,old)):
 atoms=np.array([atom.coord for atom in r if atom.element not in ['H','D']]);ca=np.linalg.norm(heavy-r['CA'].coord,axis=1).min();d=np.linalg.norm(atoms[:,None,:]-heavy[None,:,:],axis=2).min();dc=np.linalg.norm(atoms[:,None,:]-target[None,:,:],axis=2).min()
 st={'pos_1based':i+1,'wt':ref[i],'secondary_structure_c3':str(ss[i]),'flexible':bool(flex[i]),'ca_to_rna_A':round(float(ca),4),'heavy_to_rna_A':round(float(d),4),'heavy_to_rna_C388_A':round(float(dc),4),'is_trm':i in cfg['specificity_positions_0based']};struct.append(st)
 row=dict(st);nom=[]
 for m in ['proteinmpnn','ligandmpnn']:
  fm=float(o[m+'_f_alt']);fw=float(o[m+'_f_wt']);passed=fm>fw and (fm>=.8 or (flex[i] and fm>=.5)) and not st['is_trm'];row[m+'_mutation']=o[m+'_mutation'];row[m+'_f_alt']=fm;row[m+'_f_wt']=fw;row[m+'_pass']=bool(passed)
  if passed:nom.append((m,o[m+'_mutation']))
 row['exact_consensus']=len(nom)==2 and nom[0][1]==nom[1][1];positions.append(row)
 for mut in sorted({x for _,x in nom}):
  support=[m for m,x in nom if x==mut];c=dict(st);c.update(mutation=mut,supporting_models=';'.join(support),support_count=len(support),exact_consensus=len(support)==2,new_vs_global=mut not in baseline_muts,training_mutated_constructs=int(o['training_mutated_constructs']))
  for m in ['proteinmpnn','ligandmpnn']:
   # Model-specific preferred alternative may differ; do not mislabel its frequency as this mutation's frequency.
   c[m+'_preferred_mutation']=o[m+'_mutation'];c[m+'_preferred_f_alt']=float(o[m+'_f_alt']);c[m+'_f_wt']=float(o[m+'_f_wt']);c[m+'_supports_this_mutation']=m in support
  c['screen_routes']=';'.join(m+(' global' if float(o[m+'_f_alt'])>=.8 else ' flexible') for m in support)
  # Preserve the original heuristic for traceability, not a calibrated fitness score.
  c['legacy_heuristic']=max(float(o[m+'_f_alt']) for m in ['proteinmpnn','ligandmpnn'])+.2*(len(support)==2)+.1*(ca<10)
  cand.append(c)
assert baseline_muts<={r['mutation'] for r in cand}
cand.sort(key=lambda r:(-r['support_count'],-r['legacy_heuristic'],r['pos_1based']))
def write(name,rows):
 with (a.out/name).open('w') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
write('structure_annotations.csv',struct);write('all_positions.csv',positions);write('nontrm_candidates.csv',cand);write('exact_consensus.csv',[r for r in cand if r['exact_consensus']]);write('added_by_flexibility.csv',[r for r in cand if r['new_vs_global']])
with (a.out/'single_mutants.fasta').open('w') as f:
 f.write('>WT\n'+ref+'\n')
 for r in cand:
  i=r['pos_1based']-1;s=ref[:i]+r['mutation'][-1]+ref[i+1:];assert sum(x!=y for x,y in zip(s,ref))==1;assert all(s[j]==ref[j] for j in cfg['specificity_positions_0based']);f.write('>'+r['mutation']+'\n'+s+'\n')
validation={'method':'AiCE_single-inspired; PyDSSP 3-state approximation','beta':.8,'gamma':.5,'flexibility_encoding':'PyDSSP index 0, c3 -; not C','structure_counts':{str(k):int((ss==k).sum()) for k in sorted(set(ss))},'candidate_positions':len({r['pos_1based'] for r in cand}),'candidate_substitutions':len(cand),'exact_consensus':sum(r['exact_consensus'] for r in cand),'added_substitutions':sum(r['new_vs_global'] for r in cand),'baseline_retained':True,'all_single_mutant_sequences_validated':True,'pdb_sequence_matches_reference':True,'input_sha256':{str(x.relative_to(a.repo)):hashlib.sha256(x.read_bytes()).hexdigest() for x in [pdb,b/'inputs/design_config.json']},'versions':{x:importlib.metadata.version(x) for x in ['numpy','biopython','pydssp','torch']},'python':platform.python_version()}
(a.out/'validation.json').write_text(json.dumps(validation,indent=2));print(json.dumps(validation,indent=2));print('NEW CONSENSUS',[(r['mutation'],r['new_vs_global']) for r in cand if r['exact_consensus']])
