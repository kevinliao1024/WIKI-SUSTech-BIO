from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
import csv,json
out=Path('outputs/nontrm_aice_structural');rows=sorted(csv.DictReader((out/'exact_consensus.csv').open()),key=lambda r:int(r['pos_1based']))
fontpath='/System/Library/Fonts/Supplemental/Arial.ttf'
im=Image.new('RGB',(2200,1850),'white');d=ImageDraw.Draw(im)
def text(x,y,s,size=25,fill='#202D3A'):d.text((x,y),s,font=ImageFont.truetype(fontpath,size),fill=fill)
text(90,45,'AiCE-inspired non-TRM single substitutions',48);text(90,112,'46 exact dual-model nominations | 125 positions / 128 substitutions overall',30)
for col,subset in enumerate([rows[:23],rows[23:]]):
 left=270+col*1070;top=230;width=780;step=60
 for tick in [0,.2,.4,.5,.6,.8,1]:
  x=left+tick*width;d.line((x,top-20,x,top+22*step+25),fill='#D0D0D0',width=2)
  text(x-16,top+22*step+40,str(tick),22)
 for j,r in enumerate(subset):
  y=top+j*step;label=r['mutation']+(' *' if r['flexible']=='True' else '');text(left-175,y-14,label,27)
  x1=left+width*float(r['proteinmpnn_preferred_f_alt']);x2=left+width*float(r['ligandmpnn_preferred_f_alt']);d.line((x1,y,x2,y),fill='#888888',width=3)
  d.ellipse((x1-8,y-8,x1+8,y+8),fill='#0072B2');d.rectangle((x2-7,y-7,x2+7,y+7),fill='#A34B00')
 text(left-70,top+22*step+82,'Appearance frequency (10,000 samples / model)',24)
d.ellipse((100,1697,118,1715),fill='#0072B2');text(130,1690,'ProteinMPNN',25);d.rectangle((400,1697,418,1715),fill='#A34B00');text(435,1690,'LigandMPNN',25)
text(90,1740,'* PyDSSP loop: threshold 0.5; all other positions: 0.8. Positions are ordered by protein coordinate.',25)
text(90,1782,'Model sequence preferences; no experimentally established improvement. PyDSSP is a 3-state approximation.',25)
im.save(out/'consensus.png',dpi=(200,200))
(out/'figure_metadata.json').write_text(json.dumps({'source':'exact_consensus.csv','pixels':[2200,1850],'dpi':200,'renderer':'Pillow','axis':'linear frequency 0 to 1','ordering':'position','uncertainty':'descriptive frequencies, one structure/seed, no biological replicates','alt_text':'All 46 consensus substitutions, with circles for ProteinMPNN and squares for LigandMPNN. Asterisks label PyDSSP loops. Data are in exact_consensus.csv.'},indent=2))
