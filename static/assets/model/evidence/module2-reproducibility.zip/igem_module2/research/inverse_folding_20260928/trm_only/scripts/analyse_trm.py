from pathlib import Path
import argparse,csv,gzip,json,hashlib,collections,re,statistics
import numpy as np
p=argparse.ArgumentParser();p.add_argument('--sampling-dir',type=Path,required=True);p.add_argument('--repo',type=Path,required=True);p.add_argument('--previous',type=Path,required=True);p.add_argument('--experiments',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--expected',type=int,default=10000);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=False)
b=a.repo/'research/aice_mpnn_20260922';cfg=json.loads((b/'inputs/design_config.json').read_text());positions=cfg['specificity_positions_0based'];trm=set(positions);assert len(trm)==36
struct={int(r['pos_1based'])-1:r for r in csv.DictReader((a.previous/'structure_annotations.csv').open())};AA='ACDEFGHIKLMNPQRSTVWY'
def read_fasta(path):
 out=[];head=None;seq=[]
 with path.open() as f:
  for ln in f:
   if ln.startswith('>'):
    if head is not None:out.append((head,''.join(seq)))
    head=ln.strip()[1:];seq=[]
   else:seq.append(ln.strip())
  if head is not None:out.append((head,''.join(seq)))
 return out
def write(n,rs):
 if not rs:return
 with (a.out/n).open('w',newline='',encoding='utf-8-sig') as f:
  w=csv.DictWriter(f,fieldnames=list(rs[0]));w.writeheader();w.writerows(rs)
models={};stats={};native=None;sample_tables=[]
for m in ['ligand_mpnn','protein_mpnn']:
 path=a.sampling_dir/('full_'+m)/'seqs/complex.fa';records=read_fasta(path);ref=records[0][1]
 assert len(ref)==493 and len(records)==a.expected+1
 if native is None:native=ref
 assert native==ref
 arr=np.array([list(s) for _,s in records[1:]])
 assert arr.shape==(a.expected,493) and set(np.unique(arr))<=set(AA)
 assert np.all(arr[:,[i for i in range(493) if i not in trm]]==np.array(list(ref))[[i for i in range(493) if i not in trm]])
 freq=np.stack([(arr==x).mean(0) for x in AA],axis=1);assert np.allclose(freq.sum(1),1)
 modelrows=[]
 for num,(h,s) in enumerate(records[1:],1):
  fields=dict(re.findall(r'(\w+)=([^, ]+)',h));assert int(fields['id'])==num
  r={'model':m,'sample_id':num,'n_TRM_changes':sum(x!=y for x,y in zip(ref,s)),'overall_confidence':float(fields['overall_confidence']),'rna_proximal_confidence':float(fields['ligand_confidence']) if m=='ligand_mpnn' else None,'TRM_sequence':''.join(s[i] for i in positions),'sequence':s}
  modelrows.append(r)
 modelrows.sort(key=lambda r:(-r['overall_confidence'],r['sample_id']));seen=set();top=[]
 for r in modelrows:
  if r['sequence'] not in seen:top.append(r);seen.add(r['sequence'])
  if len(top)==20:break
 write(m+'_top20_samples.csv',top)
 with gzip.open(a.out/(m+'_10000_samples.fasta.gz'),'wt') as f:
  for num,(h,s) in enumerate(records[1:],1):f.write(f'>{m}_sample_{num}\n{s}\n')
 models[m]={'arr':arr,'freq':freq};stats[m]={'samples':len(arr),'unique_sequences':len({s for _,s in records[1:]}),'nonTRM_fixed':True,'mean_TRM_changes':float(np.mean([r['n_TRM_changes'] for r in modelrows])),'min_TRM_changes':min(r['n_TRM_changes'] for r in modelrows),'max_TRM_changes':max(r['n_TRM_changes'] for r in modelrows),'source_fasta_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
rows=[];long=[];nominations=[]
for i in positions:
 wt=native[i];ss=struct[i];flex=ss['flexible']=='True';rep=next(r for r in cfg['repeats'] if i in [r['pos12'],r['pos13'],r['pos16']]);row={'pos_1based':i+1,'wt':wt,'repeat':rep['repeat'],'ss':ss['secondary_structure_c3'],'flexible':flex,'threshold':.5 if flex else .8,'heavy_to_RNA_A':ss['heavy_to_rna_A']};noms=[]
 for m,st in models.items():
  f=st['freq'][i];fw=float(f[AA.index(wt)]);alt=f.copy();alt[AA.index(wt)]=-1;k=alt.argmax();fm=float(alt[k]);mut=f'{wt}{i+1}{AA[k]}';passed=fm>fw and (fm>=.8 or (flex and fm>=.5))
  row.update({m+'_mutation':mut,m+'_f_alt':fm,m+'_f_wt':fw,m+'_pass':bool(passed)})
  if passed:noms.append((m,mut))
  for aa,fr in zip(AA,f):long.append({'model':m,'repeat':rep['repeat'],'pos_1based':i+1,'wt':wt,'aa':aa,'count':int(round(fr*a.expected)),'frequency':float(fr)})
 row['exact_consensus']=len(noms)==2 and noms[0][1]==noms[1][1];rows.append(row)
 for mut in sorted({x for _,x in noms}):
  support=[m for m,x in noms if x==mut];r={'mutation':mut,'pos_1based':i+1,'repeat':rep['repeat'],'flexible':flex,'supporting_models':';'.join(support),'exact_consensus':len(support)==2}
  for m,st in models.items():r[m+'_tested_alt_frequency']=float(st['freq'][i,AA.index(mut[-1])]);r[m+'_wt_frequency']=float(st['freq'][i,AA.index(wt)])
  nominations.append(r)
write('trm_position_screen.csv',rows);write('trm_amino_acid_frequencies.csv',long);write('trm_single_nominations.csv',nominations)
# Joint triplet distributions, retaining all observed triplets and WT even if absent.
triplets=[];toptrips=[]
for rp in cfg['repeats']:
 ix=[rp['pos12'],rp['pos13'],rp['pos16']];wt=''.join(native[i] for i in ix);cnt={m:collections.Counter(''.join(r) for r in st['arr'][:,ix]) for m,st in models.items()}
 for trip in sorted(set([wt])|set(cnt['ligand_mpnn'])|set(cnt['protein_mpnn'])):
  r={'repeat':rp['repeat'],'wt_triplet':wt,'triplet':trip,'is_wt':trip==wt,'positions_1based':';'.join(str(i+1) for i in ix)}
  for m in models:r[m+'_count']=cnt[m][trip];r[m+'_frequency']=cnt[m][trip]/a.expected
  triplets.append(r)
 for m in models:
  for rank,(trip,n) in enumerate(cnt[m].most_common(10),1):toptrips.append({'model':m,'repeat':rp['repeat'],'rank_within_repeat':rank,'wt_triplet':wt,'triplet':trip,'count':n,'frequency':n/a.expected,'wt_frequency':cnt[m][wt]/a.expected})
write('all_observed_triplets.csv',triplets);write('top10_triplets_per_repeat.csv',toptrips)
# Matched empirical support for measured constructs, no outcome threshold or re-fit.
exper=list(csv.DictReader((a.experiments/'construct_comparison.csv').open(encoding='utf-8-sig')));expout=[]
for e in exper:
 if e['control']=='True':continue
 muts=e['mutations'].split(';');mutix=[int(x[1:-1])-1 for x in muts];assert set(mutix)<=trm
 seq=list(native)
 for mut,i in zip(muts,mutix):assert seq[i]==mut[0];seq[i]=mut[-1]
 repeats=[r for r in cfg['repeats'] if set(mutix)&{r['pos12'],r['pos13'],r['pos16']}];rix=[i for r in repeats for i in [r['pos12'],r['pos13'],r['pos16']]]
 r={k:e[k] for k in ['batch','group','name','mutations','C295_mean','C388_mean','C871_mean','source_file','sheet','rows']};r['joint_motifs']=';'.join('P'+str(rp['repeat'])+':'+''.join(seq[i] for i in [rp['pos12'],rp['pos13'],rp['pos16']]) for rp in repeats)
 for m,st in models.items():
  arr=st['arr'];r[m+'_mutated_residues_match_count']=int(np.all(arr[:,mutix]==np.array(seq)[mutix],axis=1).sum());r[m+'_whole_motifs_match_count']=int(np.all(arr[:,rix]==np.array(seq)[rix],axis=1).sum());r[m+'_exact_full_genotype_count']=int(np.all(arr[:,positions]==np.array(seq)[positions],axis=1).sum())
  r[m+'_joint_motif_frequency']=r[m+'_whole_motifs_match_count']/a.expected
 expout.append(r)
write('experimental_construct_comparison.csv',expout)
with (a.out/'single_mutant_nominations.fasta').open('w') as f:
 f.write('>WT\n'+native+'\n')
 for r in nominations:
  i=r['pos_1based']-1;s=native[:i]+r['mutation'][-1]+native[i+1:];assert sum(x!=y for x,y in zip(native,s))==1;f.write('>'+r['mutation']+'\n'+s+'\n')
v={'models':stats,'TRM_positions':36,'fixed_nonTRM_positions':457,'thresholds':{'beta':.8,'gamma':.5},'synonymous_code_filter':False,'candidate_positions':len({r['pos_1based'] for r in nominations}),'candidate_substitutions':len(nominations),'exact_consensus_substitutions':sum(r['exact_consensus'] for r in nominations),'experimental_constructs_compared':len(expout),'exact_experimental_single_overlap':sorted({r['mutation'] for r in nominations}&{x for e in exper for x in e['mutations'].split(';')}),'binding_affinity_validated':False}
(a.out/'validation.json').write_text(json.dumps(v,indent=2));print(json.dumps(v,indent=2))
