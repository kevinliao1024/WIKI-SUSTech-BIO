from pathlib import Path
import csv,gzip,json,collections
import numpy as np
import argparse
p=argparse.ArgumentParser();p.add_argument('--repo',type=Path,required=True);p.add_argument('--results',type=Path,required=True);a=p.parse_args();cfg=json.loads((a.repo/'research/aice_mpnn_20260922/inputs/design_config.json').read_text());pos=cfg['specificity_positions_0based'];AA='ACDEFGHIKLMNPQRSTVWY';new=list(csv.DictReader((a.results/'trm_amino_acid_frequencies.csv').open(encoding='utf-8-sig')));lookup={(r['model'],int(r['pos_1based']),r['aa']):float(r['frequency']) for r in new};out=[]
for model in ['ligandmpnn','proteinmpnn']:
 path=a.repo/f'research/aice_mpnn_20260922/results/mpnn_samples_{model}.fa.gz';seqs=[];seq=''
 with gzip.open(path,'rt') as f:
  for l in f:
   if l.startswith('>'):
    if seq:seqs.append(seq)
    seq=''
   else:seq+=l.strip()
  seqs.append(seq)
 assert len(seqs)==10001;arr=np.array([list(s) for s in seqs[1:]]);m=model.replace('mpnn','_mpnn')
 for i in pos:
  for aa in AA:
   old=float((arr[:,i]==aa).mean());fresh=lookup[(m,i+1,aa)];out.append({'model':m,'pos_1based':i+1,'aa':aa,'old_all_protein_design_frequency':old,'new_TRM_only_design_frequency':fresh,'change':fresh-old})
with (a.results/'old_vs_TRM_only_frequencies.csv').open('x',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(out[0]));w.writeheader();w.writerows(out)
