"""Run two fresh TRM-only ensembles from a portable result bundle.
Requires CPU PyTorch, ProDy, NumPy and the pinned environment. No system changes.
"""
import argparse,subprocess,os,json
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--weights',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--python',default='python');a=p.parse_args();root=Path(__file__).resolve().parents[1];assert not a.out.exists(),'Refuse to overwrite output directory';a.out.mkdir(parents=True)
cfg=json.loads((root/'inputs/design_config.json').read_text());pos=' '.join('A'+str(i+1) for i in cfg['specificity_positions_0based']);env=os.environ.copy();env.update(MPNN_DEVICE='cpu',MPNN_THREADS='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
for m,ck in [('ligand_mpnn','ligandmpnn_v_32_010_25.pt'),('protein_mpnn','proteinmpnn_v_48_020.pt')]:
 cmd=[a.python,str(root/'scripts/run_device.py'),'--model_type',m,'--checkpoint_'+m,str((a.weights/ck).resolve()),'--pdb_path',str(root/'inputs/complex.pdb'),'--out_folder',str(a.out/('full_'+m)),'--chains_to_design','A','--redesigned_residues',pos,'--seed','111','--temperature','0.5','--batch_size','50','--number_of_batches','200','--save_stats','1','--verbose','0']
 with (a.out/(m+'.log')).open('w') as log:subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
