#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
OUT="${1:?Supply a NEW output directory}"
if [ -e "$OUT" ]; then echo "Output already exists" >&2; exit 1; fi
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1
"${PYTHON:-python}" "$ROOT/scripts/audit_nontrm.py" --repo "$ROOT/inputs/repo" --reuse "$ROOT/inputs/reuse" --out "$OUT/baseline"
"${PYTHON:-python}" "$ROOT/scripts/structure_screen.py" --repo "$ROOT/inputs/repo" --baseline "$OUT/baseline" --out "$OUT/structural"
