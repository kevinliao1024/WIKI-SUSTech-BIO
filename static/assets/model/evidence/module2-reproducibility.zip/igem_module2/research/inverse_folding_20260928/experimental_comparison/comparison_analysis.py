from pathlib import Path
import csv,json,re,gzip,hashlib,statistics
import openpyxl,numpy as np
OUT=Path('outputs/nontrm_vs_two_batches');OUT.mkdir(exist_ok=True)
base=Path('work/PUF_alphafold/research/aice_mpnn_20260922')
ref=json.loads(Path('work/reuse_input/igem_module2/wiki/ablation_experiment/inputs/reference.json').read_text())['reference'];cfg=json.loads((base/'inputs/design_config.json').read_text());trm={x+1 for x in cfg['specificity_positions_0based']}
manifest=list(csv.DictReader(open('work/reuse_input/igem_module2/wiki/ablation_experiment/inputs/construct_manifest.csv')))
pred=list(csv.DictReader(open('outputs/nontrm_aice_structural/nontrm_candidates.csv')));predm={r['mutation'] for r in pred};predp={int(r['pos_1based']) for r in pred}
def key(s,b):
 s=re.sub(r'^[ab](?=\d)','',s.lower())
 if b==1:s=re.sub(r'^\d+\s+','',s)
 return re.sub(r'[^a-z0-9]+','_',s.replace('+','_plus_')).strip('_')
def write(n,rows):
 with (OUT/n).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
records=[];groups={};hashes={}
for batch,nm,sheet,cols,notes in [(1,'副本第一批.xlsx','分组核对结果',[2,3,4],[6,7,8]),(2,'副本第二批.xlsx','同名样本归组',[3,4,5],[8,9,10])]:
 path=Path(__import__('os').environ['PUF_WORKBOOK_DIR'])/nm;hashes[nm]=hashlib.sha256(path.read_bytes()).hexdigest();w=openpyxl.load_workbook(path,data_only=True);s=w[sheet]
 for row in range(2,s.max_row+1):
  name=s.cell(row,1).value
  if not name:continue
  k=key(name,batch);r={'batch':batch,'group':k,'source_file':nm,'sheet':sheet,'source_row':row,'name':name}
  for ep,col,note in zip(['C295','C388','C871'],cols,notes):
   val=s.cell(row,col).value;assert isinstance(val,(int,float)) and 0<=val<=1;r[ep]=val;r[ep+'_not_detected']='未检出' in str(s.cell(row,note).value)
  records.append(r);groups.setdefault((batch,k),[]).append(r)
summary=[];mutrows=[]
for (b,k),rs in groups.items():
 mm=[r for r in manifest if r['batch']=='batch'+str(b) and r['construct_id']==k]
 if 'puf12_9' in k: mm=[{'puf_sequence':ref,'mutation_identity':''}]
 assert len(mm)==1,(b,k,len(mm));m=mm[0];seq=m['puf_sequence'];assert len(seq)==493
 muts=[f'{x}{i+1}{y}' for i,(x,y) in enumerate(zip(ref,seq)) if x!=y];assert ';'.join(muts)==m['mutation_identity'] or (not muts and not m['mutation_identity'])
 # Independent mapping from motif names to configured positions, including 6-aa local motif.
 if muts:
  constructed=list(ref)
  motifs=re.findall(r'P(\d+)-(?:[RP]\d+-)?([A-Z]{3,6})',rs[0]['name'])
  assert motifs,rs[0]['name']
  for repeat,code in motifs:
   rp=cfg['repeats'][int(repeat)-1]
   positions=[rp['pos12'],rp['pos13'],rp['pos16']] if len(code)==3 else list(range(rp['pos12'],rp['pos12']+len(code)))
   for pos,aa in zip(positions,code):constructed[pos]=aa
  assert ''.join(constructed)==seq,(k,muts,motifs)
 g={'batch':b,'group':k,'name':rs[0]['name'],'source_file':rs[0]['source_file'],'sheet':rs[0]['sheet'],'rows':';'.join(str(r['source_row']) for r in rs),'n_records':len(rs),'mutations':';'.join(muts),'control':not muts,'n_mutations':len(muts),'all_mutations_TRM':bool(muts) and all(int(x[1:-1]) in trm for x in muts),'exact_prediction_overlap':';'.join(x for x in muts if x in predm),'same_position_overlap':';'.join(x for x in muts if int(x[1:-1]) in predp)}
 for ep in ['C295','C388','C871']:
  g[ep+'_mean']=statistics.mean(r[ep] for r in rs);g[ep+'_min']=min(r[ep] for r in rs);g[ep+'_max']=max(r[ep] for r in rs);g[ep+'_not_detected_records']=sum(r[ep+'_not_detected'] for r in rs)
 summary.append(g)
 for mut in muts:mutrows.append({'batch':b,'group':k,'mutation':mut,'pos_1based':int(mut[1:-1]),'is_TRM':int(mut[1:-1]) in trm,'exact_prediction_overlap':mut in predm,'same_position_overlap':int(mut[1:-1]) in predp})
# Raw model preference at measured mutations: descriptive only, no TRM filter relaxed.
AA='ACDEFGHIKLMNPQRSTVWY';freqs={}
for model in ['proteinmpnn','ligandmpnn']:
 with gzip.open(base/f'results/mpnn_samples_{model}.fa.gz','rt') as f:
  seqs=[];s=''
  for ln in f:
   if ln.startswith('>'):
    if s:seqs.append(s)
    s=''
   else:s+=ln.strip()
  seqs.append(s)
 assert seqs[0]==ref and len(seqs)==10001
 arr=np.frombuffer(''.join(seqs[1:]).encode(),dtype='S1').reshape(10000,493)
 freqs[model]=np.stack([(arr==a.encode()).mean(0) for a in AA],1)
for r in mutrows:
 i=r['pos_1based']-1;x=r['mutation'][-1]
 for model,f in freqs.items():
  alt=f[i].copy();alt[AA.index(ref[i])]=-1
  r[model+'_tested_alt_freq']=float(f[i,AA.index(x)]);r[model+'_wt_freq']=float(f[i,AA.index(ref[i])]);r[model+'_tested_alt_more_frequent_than_wt']=bool(f[i,AA.index(x)]>f[i,AA.index(ref[i])]);r[model+'_top_nonwt_aa']=AA[alt.argmax()]
contrasts=[]
for g in summary:
 if g['control']:continue
 for ctrl in [x for x in summary if x['batch']==g['batch'] and x['control']]:
  c={'batch':g['batch'],'group':g['group'],'mutations':g['mutations'],'reference_group':ctrl['group'],'interpretation':'same-batch descriptive difference; experimental pairing not confirmed'}
  for ep in ['C295','C388','C871']:c[ep+'_delta_pp']=100*(g[ep+'_mean']-ctrl[ep+'_mean'])
  contrasts.append(c)
write('source_records.csv',records);write('construct_comparison.csv',summary);write('measured_mutation_model_frequencies.csv',mutrows);write('within_batch_descriptive_differences.csv',contrasts)
valid={'source_sha256':hashes,'records':len(records),'groups':len(summary),'mutant_groups':sum(not x['control'] for x in summary),'control_groups':sum(x['control'] for x in summary),'unique_measured_mutations':len({r['mutation'] for r in mutrows}),'unique_measured_positions':len({r['pos_1based'] for r in mutrows}),'all_measured_positions_TRM':all(r['is_TRM'] for r in mutrows),'exact_overlap':len({r['mutation'] for r in mutrows}&predm),'position_overlap':len({r['pos_1based'] for r in mutrows}&predp),'all_name_mappings_match_manifest_sequences':True,'all_groups_two_records':all(g['n_records']==2 for g in summary)}
(OUT/'validation.json').write_text(json.dumps(valid,ensure_ascii=False,indent=2));print(json.dumps(valid,ensure_ascii=False,indent=2))
for g in summary:
 if g['control'] or any(x in g['group'] for x in ['syvirr','p8_r6_gve','p9_ntq','p4_r5_sne','p11_ckr']):print(g['group'],g['mutations'],[round(g[e+'_mean']*100,3) for e in ['C295','C388','C871']],g['rows'])
