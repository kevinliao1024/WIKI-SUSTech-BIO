# PUF inverse-folding evidence, 2026-09-28

This is the main repository copy of the current analysis. `nontrm/` reanalyses archived all-position samples; `trm_only/` contains newly generated 10,000-sequence sets for each model; `experimental_comparison/` contains descriptive workbook-derived records and exact mutation comparisons.

Scientific output files are copied without changes. The comparison source script alone replaces a personal absolute workbook directory with `PUF_WORKBOOK_DIR`. It preserves the original historical workspace-relative input/output paths; use it as an audit source, or recreate those paths before running. The standalone non-TRM and TRM packages contain their own reproduction instructions. Raw workbooks are not redistributed. No new training or measurements are introduced in this publication step.

Main interpretation and updated figures: ../../wiki/inverse_folding_20260928/Part2_inverse_folding_EN.md
