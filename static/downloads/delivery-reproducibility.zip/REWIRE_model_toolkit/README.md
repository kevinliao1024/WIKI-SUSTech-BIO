# REWIRE model toolkit

A reusable Python research toolkit for running and inspecting the supplied REWIRE / brain-delivery model. The package separates model equations, configuration, CSV inputs, analysis routines and presentation so another team can inspect the assumptions and reproduce computational workflows.

This is a compact software source distribution from `model_v4_work` in `REWIRE_model_deliverables_20261016.zip`. Scientific Python files, YAML configurations, CSV templates and original tests in this distribution are copied byte for byte. No model parameters, thresholds, biological labels or statistical methods were changed while packaging.

**Citation correction (revision 2):** see `CITATION_NOTES.txt`. The AAV PBPK paper with DOI `10.1016/j.xphs.2023.10.005` is Liu et al. (2024). The retained original reference note misattributes it to Zhang et al.; the correction note supplies the verified citation and limits its parameter claims. The original source files remain unchanged.

## What it does

- Solves a compartmental ODE model across absorption, systemic distribution, BBB transport, intracellular expression and RNA-editing dynamics.
- Exposes a command-line interface and importable Python modules; the supplied configuration selects the APOE multisite editing model.
- Exports numerical state trajectories, metadata and diagnostic plots.
- Includes existing dose-scan, uncertainty, parameter-fitting and benchmark routines, with explicit parameter provenance and assay / candidate-panel CSV contracts.
- Includes an optional local FastAPI dashboard and its HTML/CSS/JavaScript source.

This is an exploratory, literature-informed model, not a clinically calibrated system. Dose units and many rate constants are normalized model quantities. Outputs are not treatment recommendations. The CSV templates contain illustrative values or priors, not a validated experimental dataset.

## Start with a small local check

Use Python 3.12 in your own existing isolated environment. The core workflow needs NumPy, SciPy, Matplotlib and PyYAML. The exact core versions used for the packaging smoke check are recorded in `requirements-core-tested.txt`.

```bash
cd REWIRE_model_toolkit
python -m venv .venv
# Activate .venv using your platform's normal activation command.
python -m pip install -r requirements-core-tested.txt
python main.py --help
python smoke_check.py
```

The smoke check runs one short, three-timepoint trajectory with the original configuration and performs six existing lightweight contract tests. It does not scan doses, fit parameters or run uncertainty analysis. It writes no files. The one-hour horizon is a software fixture only and does not reproduce the full scientific figures.

To exercise the original CLI and its output writer with the same small fixture:

```bash
python main.py --t_end 1 --dt 0.5 --output_dir outputs/quickstart
```

Each output directory is relative to the extracted package root. Use a new directory for each run: the original output writer uses fixed filenames and will overwrite a previous run in the same folder. The original configuration defaults remain 48 hours and a 0.1-hour output interval. Use compatible time / step values; the unchanged simulator constructs its grid using `numpy.arange` and some floating-point combinations can extend beyond the requested horizon.

## Inputs and outputs

| Item | Contract / role |
| --- | --- |
| `config/base_config.yaml` | Original route, model, rates, thresholds and analysis defaults. Preserve a copy with every analysis. |
| `config/parameter_provenance.yaml` | Original parameter priors and provenance. |
| `wetlab/templates/assay_observations_template.csv` | Assay, time, value, standard deviation, weight and notes; illustrative data require replacement with an independently validated dataset. |
| `wetlab/templates/offtarget_candidate_panel_template.csv` | Candidate-site fields used by the original panel summarizer. |
| `wetlab/templates/puf_design_candidates_template.csv` | Predefined feature table consumed by the original model; it does not generate a biological sequence. |
| `simulation_results.npz` | `t` (time), `y` (state × time) and `state_order`. The original `state_order` array has object dtype; only load trusted files with pickle enabled if that field is needed. |
| `metadata.json` | Dose, route and number of states. Solver status is returned by `run_simulation` but is not included in this legacy metadata file. |
| Module PNG plots | Existing diagnostic plots. The separately provided ORCA vector figures are presentation assets, not the runtime dependency of this software. |

## Reuse the Python API

Run from the extracted package root:

```python
from pathlib import Path
from utils.config_loader import load_base_config
from models.full_model.simulator import run_simulation

config = load_base_config(Path.cwd())
result = run_simulation(config, dose=1.0, t_end=1.0, dt=0.5)
assert result["success"], result["message"]
print(result["t"].shape, result["y"].shape)
```

The CLI accepts route, dose, horizon, output step and output directory; it has no `--config` option. To use a separate configuration without modifying the supplied default, load your own YAML with `utils.config_loader.load_yaml` and pass the resulting dictionary to `run_simulation`. Keep scientific changes under your own review process.

## Optional local dashboard

The unchanged `requirements.txt` lists the original core and web dependencies. The web stack was not present in the packaging environment, so dashboard behavior was not validated in this release.

```bash
python -m pip install -r requirements.txt
python run_brain_app.py
```

Open `http://127.0.0.1:8001`. The server binds to localhost. It is a local research interface, with no production authentication or job queue. The interface offers route / preset / duration selection, a single simulation or configured dose scan, an optional candidate-panel CSV and interactive result curves. `IGEM_WIKI_URL` can set the return link. This bundled dashboard is distinct from the separate `igem_software` website discussed on the Wiki.

## Advanced routines and scope

`scripts/run_iterated_analysis.py --help` describes the existing combined analysis options. `scripts/run_design_uncertainty.py --help` and `benchmarks/run_benchmarks.py --help` expose their own interfaces. These routines may perform many simulations; the packaging checks did not execute them. Preserve the supplied seeds and original parameters when reproducing earlier analyses.

Excluded from this compact download: pre-rendered figures, historical notebook output, duplicated Wiki prose, the compiled probe binary, the external PhysiCell / ParaView spatial extension, and the separate legacy Module-1 fitting demo that requires an additional undeclared pandas dependency. Core calibration routines under `models/calibration/` remain included. This source package alone is not a guarantee of exact regeneration of every historical or ORCA-redrawn figure.

## Reproducibility and validation

Read `VALIDATION.json` for checks actually performed, versions and scope. `SOURCE_MANIFEST.json` records checksums of the unchanged supplied files. `SHA256SUMS` covers the packaged files. The archive itself has a separate checksum next to the download.

The software smoke checks establish computational operation and input/output structure. They do not establish biological accuracy, experimental validity or clinical suitability. No full-data scan, parameter fitting, full benchmark suite, web integration test or spatial-model run was performed during packaging. A fresh environment installation was not tested; the checked runtime already had the four core libraries available.

## License and attribution

No license file was found in the supplied model source. This packaging step does not grant a new software license or alter ownership. Review `LICENSE_STATUS.txt` and obtain permission from the copyright holder before redistribution or reuse that requires a license. Do not describe the package as MIT-licensed or permissively open source without adding an authorized license.
