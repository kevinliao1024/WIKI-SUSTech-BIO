"""Iterated-model analysis utilities."""

