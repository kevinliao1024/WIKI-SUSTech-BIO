"""
M7: Monte Carlo uncertainty intervals for the recommended design.

Applies the recommended PUF-APOBEC design (default: 10R-proapobec) on top of
SAMPLED parameter sets — i.e. sequence-derived kinetic modifiers are treated
as deterministic design features, while the underlying biological rate
constants remain uncertain (priors from config/parameter_provenance.yaml).

Reports median + 90% prediction intervals for the decision metrics and the
probability of meeting the pre-registered decision criteria.

Usage:
    python scripts/run_design_uncertainty.py \
        --design_id 10R-proapobec --dose 0.9 --t_end 168 --samples 200 \
        --out_dir <abs path>/new_results/design_uncertainty
"""

from __future__ import annotations

import argparse
import json
import math
import random
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from utils.config_loader import load_base_config  # noqa: E402
from models.full_model.simulator import run_simulation  # noqa: E402
from models.editing.sequence_to_kinetics import (  # noqa: E402
    load_design_table,
    apply_design_to_config,
)
from optimization.metrics import extract_summary_metrics  # noqa: E402
from optimization.iterated.uncertainty import (  # noqa: E402
    load_parameter_priors,
    sample_config,
)

METRICS = [
    "apoe3_like_fraction_final",
    "ldlr_binding_risk_proxy_final",
    "off_target_burden_final",
    "specificity_index_final",
    "on_target_editing_rate_final",
]

# Pre-registered decision criteria (direction: >= or <=).
CRITERIA = {
    "apoe3_like_fraction_final": (">=", 0.30, "desired product >= 30% of APOE RNA"),
    "specificity_index_final": (">=", 5.0, "specificity index >= 5"),
    "ldlr_binding_risk_proxy_final": ("<=", 0.01, "APOE2-like risk proxy <= 1%"),
}


def percentile(xs, q):
    xs = sorted(xs)
    if not xs:
        return float("nan")
    k = (len(xs) - 1) * q
    f = math.floor(k)
    c = math.ceil(k)
    if f == c:
        return xs[int(k)]
    return xs[f] + (xs[c] - xs[f]) * (k - f)


def main() -> None:
    parser = argparse.ArgumentParser(description="Design-specific MC uncertainty scan")
    parser.add_argument("--design_id", type=str, default="10R-proapobec")
    parser.add_argument("--dose", type=float, default=0.9)
    parser.add_argument("--t_end", type=float, default=168.0)
    parser.add_argument("--dt", type=float, default=0.2)
    parser.add_argument("--samples", type=int, default=200)
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--out_dir", type=str, required=True)
    args = parser.parse_args()

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    base_config = load_base_config(ROOT)
    base_config["route"] = "footpad"
    priors = load_parameter_priors(ROOT / "config" / "parameter_provenance.yaml")
    designs = {r["design_id"]: r for r in load_design_table(ROOT / "wetlab" / "templates" / "puf_design_candidates_template.csv")}
    design = designs[args.design_id]

    rng = random.Random(args.seed)
    rows = []
    for sample_id in range(int(args.samples)):
        sampled_config, sampled = sample_config(base_config, priors, rng)
        design_config, _ = apply_design_to_config(sampled_config, design)
        sim = run_simulation(config=design_config, dose=args.dose, t_end=args.t_end, dt=args.dt)
        summary = extract_summary_metrics(sim)
        rows.append({"sample_id": sample_id, **sampled, **summary})
        if (sample_id + 1) % 25 == 0:
            print(f"  {sample_id + 1}/{args.samples} samples done")

    # ---- summarize
    summary_out = {
        "design_id": args.design_id,
        "dose": args.dose,
        "t_end_h": args.t_end,
        "n_samples": args.samples,
        "seed": args.seed,
        "metrics": {},
    }
    for m in METRICS:
        xs = [float(r[m]) for r in rows if r.get(m) is not None and math.isfinite(float(r[m]))]
        if not xs:
            continue
        entry = {
            "median": percentile(xs, 0.5),
            "p05": percentile(xs, 0.05),
            "p95": percentile(xs, 0.95),
            "mean": sum(xs) / len(xs),
            "min": min(xs),
            "max": max(xs),
        }
        if m in CRITERIA:
            op, thr, label = CRITERIA[m]
            ok = [x >= thr if op == ">=" else x <= thr for x in xs]
            entry["criterion"] = label
            entry["criterion_threshold"] = thr
            entry["prob_meet_criterion"] = sum(ok) / len(ok)
        summary_out["metrics"][m] = entry

    # ---- write outputs
    import csv
    csv_path = out_dir / "design_uncertainty_samples.csv"
    fieldnames = sorted({k for r in rows for k in r.keys()})
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    json_path = out_dir / "design_uncertainty_summary.json"
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(summary_out, f, indent=2)

    md_path = out_dir / "design_uncertainty_summary.md"
    with open(md_path, "w", encoding="utf-8") as f:
        f.write(f"# Uncertainty intervals — recommended design `{args.design_id}`\n\n")
        f.write(f"Monte Carlo over uncertain biological parameters (n={args.samples}, "
                f"dose={args.dose}, t_end={args.t_end} h, footpad route). "
                "Sequence-derived design modifiers are applied on top of each sampled parameter set.\n\n")
        f.write("| metric | median | 90% PI (p05–p95) | criterion | P(meet) |\n")
        f.write("|--------|--------|------------------|-----------|---------|\n")
        for m in METRICS:
            e = summary_out["metrics"].get(m)
            if not e:
                continue
            crit = e.get("criterion", "—")
            p = f"{e['prob_meet_criterion']:.2f}" if "prob_meet_criterion" in e else "—"
            f.write(f"| {m} | {e['median']:.4g} | {e['p05']:.4g} – {e['p95']:.4g} | {crit} | {p} |\n")

    print(f"\nDesign {args.design_id} @ dose {args.dose}, n={args.samples}")
    for m in METRICS:
        e = summary_out["metrics"].get(m)
        if e:
            p = f", P(crit)={e['prob_meet_criterion']:.2f}" if "prob_meet_criterion" in e else ""
            print(f"  {m:32s} median={e['median']:.4g}  90%PI=[{e['p05']:.4g}, {e['p95']:.4g}]{p}")
    print(f"CSV: {csv_path}\nJSON: {json_path}\nMD: {md_path}")


if __name__ == "__main__":
    main()
