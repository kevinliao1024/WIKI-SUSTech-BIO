"""Short software check only; no dose scan, fitting, or uncertainty analysis."""
from pathlib import Path
import os
import runpy
import numpy as np
from models.full_model.simulator import run_simulation
from utils.config_loader import load_base_config

def main():
    root = Path(__file__).resolve().parent
    os.chdir(root)
    test_files = (
        "test_administration_routes.py",
        "test_sequence_to_kinetics.py",
        "test_offtarget_panel.py",
        "test_wetlab_bridge.py",
    )
    passed = []
    for filename in test_files:
        namespace = runpy.run_path(str(root / "tests" / filename))
        for name, function in sorted(namespace.items()):
            if name.startswith("test_") and callable(function):
                function()
                passed.append(name)
    result = run_simulation(load_base_config(root), dose=1.0, t_end=1.0, dt=0.5)
    assert result["success"], result["message"]
    assert result["t"].shape == (3,)
    assert result["y"].shape == (len(result["state_order"]), 3)
    assert np.isfinite(result["y"]).all()
    assert result["state_order"] == list(dict.fromkeys(result["state_order"]))
    print(f"PASS: {len(passed)} existing contract tests")
    print(f"PASS: 1-hour smoke trajectory, shape={result['y'].shape}, finite values, solver success")
    print("No scientific validation or full scan was performed.")

if __name__ == "__main__":
    main()
