"""
CU-REWIRE benchmark reproduction suite (M5).

Reproduces eight published behaviors of PUF-APOBEC rewiring editors
(Han et al. NAR 2022 "CU-REWIRE"; Han et al. Nat Commun 2025 "ProAPOBEC/CU5.x")
in HEK293T transient-transfection mode, each with an explicit quantitative
target, tolerance and PASS / PARTIAL / FAIL verdict.

Unlike a demonstration-only reproduction, every benchmark reports:
  - the numeric model value,
  - the literature-derived target range,
  - the error / ratio actually achieved,
  - a test-type label separating parameterization-consistency checks
    (the model was tuned to this regime) from independent checks
    (emergent directions or quantitative ratios that were NOT fitted).

Usage:
    python benchmarks/run_benchmarks.py --out_dir <abs path>/new_results/benchmarks
"""

from __future__ import annotations

import argparse
import csv
import math
import sys
from copy import deepcopy
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from utils.config_loader import load_base_config  # noqa: E402
from models.full_model.simulator import run_simulation  # noqa: E402
from models.editing.module5 import compute_editing_metrics  # noqa: E402
from models.editing.sequence_to_kinetics import (  # noqa: E402
    load_design_table,
    apply_design_to_config,
)

T_ASSAY = 48.0   # h, standard HEK293T editing readout (Han 2022)
DT = 0.2
DESIGN_TABLE = ROOT / "wetlab" / "templates" / "puf_design_candidates_template.csv"


def run_final_metrics(base_cfg, row, dose, t_end=T_ASSAY):
    """Apply a design row, run transfection-mode simulation, return final metrics."""
    cfg, _ = apply_design_to_config(base_cfg, row)
    cfg["route"] = "transfection"
    res = run_simulation(cfg, dose=dose, t_end=t_end, dt=DT)
    if not res.get("success", False):
        raise RuntimeError(f"solver failed: {res.get('message')}")
    m = compute_editing_metrics(res["y"], res["idx"], cfg)
    out = {k: float(v[-1]) for k, v in m.items()}
    out.update(sequencing_metrics(res["y"], res["idx"]))
    return out


def sequencing_metrics(y, idx):
    """
    Assay-matched metrics: amplicon NGS (as used by Han et al.) classifies
    every APOE transcript by its edit state, including transcripts transiently
    bound in editor complexes. The native pipeline metrics instead count only
    FREE RNA pools in the numerator, which under-reports editing when editor
    is in vast excess (HEK293T overexpression sequesters product RNA in
    complexes). Both views are reported; benchmarks B1-B5/B8 use this
    sequencing view, B6/B7 use accumulated-burden views.
    """
    def g(name):
        return float(y[idx[name], -1])

    s4 = g("S_APOE4") + g("C_APOE112") + g("C_APOE158")          # unedited
    s3 = g("S_APOE3_like") + g("C_APOE158_after112")              # 112 edited
    s2 = g("S_APOE2_like")                                        # 112+158 edited
    s158 = g("S_APOE158_only") + g("C_APOE112_after158")          # 158 only
    total = s4 + s3 + s2 + s158 + 1e-12
    return {
        "seq_edited_112_fraction": (s3 + s2) / total,
        "seq_apoe2_like_fraction": s2 / total,
        "seq_158_only_fraction": s158 / total,
        "seq_unedited_fraction": s4 / total,
    }


def vary(row, **overrides):
    r = dict(row)
    r.update(overrides)
    return r


def verdict_pass(value, lo, hi):
    return lo <= value <= hi


def main() -> None:
    parser = argparse.ArgumentParser(description="CU-REWIRE benchmark reproduction suite")
    parser.add_argument("--out_dir", type=str, required=True)
    args = parser.parse_args()
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    base_cfg = load_base_config(ROOT)
    rows = {r["design_id"]: r for r in load_design_table(DESIGN_TABLE)}
    d4 = rows["10R-design-4"]

    results = []

    def add(bid, name, anchor, quantity, value, target_text, status, test_type, detail):
        results.append({
            "benchmark_id": bid,
            "benchmark": name,
            "literature_anchor": anchor,
            "model_quantity": quantity,
            "model_value": f"{value:.6g}",
            "target": target_text,
            "status": status,
            "test_type": test_type,
            "detail": detail,
        })
        print(f"[{status:7s}] {bid} {name}: value={value:.4g} target={target_text}")

    # ------------------------------------------------------------------ B1
    # Inactive deaminase (E72A-like) control: no detectable editing.
    m = run_final_metrics(base_cfg, rows["inactive-control"], dose=1.0)
    v = m["seq_edited_112_fraction"]
    status = "PASS" if v < 1e-3 else ("PARTIAL" if v < 1e-2 else "FAIL")
    add("B1", "Inactive-deaminase control yields no editing",
        "Han 2022: E72A inactive A3A -> no detectable editing",
        "edited-112 fraction (NGS view) @48h", v, "< 0.1%", status,
        "independent negative control",
        f"off-target burden={m['off_target_burden']:.3g}; bg={m['deaminase_background_burden']:.3g}")

    # ------------------------------------------------------------------ B2
    # PUF-only control (no active deaminase): no editing.
    m = run_final_metrics(base_cfg, rows["puf-only-control"], dose=1.0)
    v = m["seq_edited_112_fraction"]
    status = "PASS" if v < 1e-3 else ("PARTIAL" if v < 1e-2 else "FAIL")
    add("B2", "PUF-only control yields no editing",
        "Han 2022: PUF domain alone -> no editing",
        "edited-112 fraction (NGS view) @48h", v, "< 0.1%", status,
        "independent negative control",
        f"off-target burden={m['off_target_burden']:.3g}")

    # ------------------------------------------------------------------ B3
    # Preferred design (+2 window, UC motif, 10R) reaches tens of percent.
    m_d4 = run_final_metrics(base_cfg, d4, dose=1.0)
    v = m_d4["seq_edited_112_fraction"]
    if verdict_pass(v, 0.20, 1.00):
        status = "PASS"
    elif verdict_pass(v, 0.05, 1.00):
        status = "PARTIAL"
    else:
        status = "FAIL"
    add("B3", "Preferred design reaches tens-of-percent editing",
        "Han 2022: EGFP C504 up to ~60%, CTNNB1 20-45%; Han 2025: CU5.1 APOE c.526 ~90%",
        "edited-112 fraction (NGS view) @48h", v, "20-100%", status,
        "parameterization-consistency",
        f"APOE2-like={m_d4['seq_apoe2_like_fraction']:.4f}; free-RNA on-target={m_d4['on_target_editing_rate']:.4f}")

    # ------------------------------------------------------------------ B4
    # Editing window: moving the target C from +2 to +7 collapses editing.
    m_w7 = run_final_metrics(base_cfg, vary(d4, design_id="d4-win7", distance_112=7.0), dose=1.0)
    e2 = max(m_d4["seq_edited_112_fraction"], 1e-12)
    v = m_w7["seq_edited_112_fraction"] / e2
    status = "PASS" if v < 0.2 else ("PARTIAL" if v < 0.5 else "FAIL")
    add("B4", "Activity window collapses outside +2 position",
        "Han 2022: editable window centered on 2nd nt downstream of PUF site",
        "editing(+7) / editing(+2)", v, "< 0.20", status,
        "encoded-rule consistency",
        f"editing(+7)={m_w7['seq_edited_112_fraction']:.4f} vs editing(+2)={e2:.4f}")

    # ------------------------------------------------------------------ B5
    # UC vs CC motif preference. Literature ratio 5-18x; model ratio is
    # EMERGENT (saturation compresses the encoded 25x kcat ratio).
    m_cc = run_final_metrics(base_cfg, vary(d4, design_id="d4-cc", uc_context_112=0.0), dose=1.0)
    e_cc = max(m_cc["seq_edited_112_fraction"], 1e-12)
    v = e2 / e_cc
    if verdict_pass(v, 5.0, 18.0):
        status = "PASS"
    elif verdict_pass(v, 2.5, 25.0):
        status = "PARTIAL"
    else:
        status = "FAIL"
    add("B5", "UC-context preference over CC-context",
        "Han 2022: UCN 50.4-67.9% vs CCN 2.8-11.6% editing (ratio ~5-18x)",
        "editing(UC) / editing(CC)", v, "5-18x", status,
        "independent quantitative check (not fitted)",
        f"UC={e2:.4f}, CC={e_cc:.4f}; encoded kcat ratio=25x, saturation compresses output")

    # ------------------------------------------------------------------ B6
    # 10-repeat PUF is more specific than 8-repeat: PUF-dependent off-target
    # (mismatch) burden ratio. Total burden includes the deaminase background
    # shared by both designs, which dilutes the PUF-specific signal, so the
    # PUF-mismatch branch is the quantity the Han 2022 8R->10R claim addresses.
    m_8r = run_final_metrics(base_cfg, rows["8R-design-2"], dose=1.0)
    b10 = max(m_d4["puf_mismatch_burden"], 1e-12)
    v = m_8r["puf_mismatch_burden"] / b10
    if v >= 3.0:
        status = "PASS"
    elif v >= 1.5:
        status = "PARTIAL"
    else:
        status = "FAIL"
    add("B6", "10R PUF more specific than 8R PUF",
        "Han 2022: extending PUF recognition 8R->10R strongly reduces off-target editing",
        "PUF-mismatch burden(8R) / (10R)", v, ">= 3x", status,
        "direction test (magnitude partially encoded)",
        f"8R puf-mismatch={m_8r['puf_mismatch_burden']:.5f}, 10R={b10:.5f}; "
        f"total-burden ratio={m_8r['off_target_burden']/max(m_d4['off_target_burden'],1e-12):.2f}x")

    # ------------------------------------------------------------------ B7
    # Free-deaminase background: >0 for active editor, scales with expression,
    # exactly zero for inactive control.
    m_lo = run_final_metrics(base_cfg, d4, dose=0.5)
    m_hi = run_final_metrics(base_cfg, d4, dose=2.0)
    m_in = run_final_metrics(base_cfg, rows["inactive-control"], dose=2.0)
    bg_lo = m_lo["deaminase_background_burden"]
    bg_hi = m_hi["deaminase_background_burden"]
    bg_in = m_in["deaminase_background_burden"]
    v = bg_hi / max(bg_lo, 1e-12)
    ok = (bg_hi > bg_lo > 0.0) and (bg_in == 0.0)
    status = "PASS" if ok else ("PARTIAL" if bg_hi > 0 and bg_in == 0.0 else "FAIL")
    add("B7", "Deaminase background scales with expression, zero when inactive",
        "Han 2022: free A3A gives dose-dependent background editing (~20% unfused)",
        "bg(dose 2.0) / bg(dose 0.5)", v, "> 1, bg(inactive)=0", status,
        "direction test",
        f"bg(0.5)={bg_lo:.4f}, bg(2.0)={bg_hi:.4f}, bg(inactive)={bg_in:.3g}")

    # ------------------------------------------------------------------ B8
    # Time course: editing accumulates monotonically across 24/48/72 h.
    ts = [24.0, 48.0, 72.0]
    e_ts = [run_final_metrics(base_cfg, d4, dose=1.0, t_end=t)["seq_edited_112_fraction"] for t in ts]
    mono = all(e_ts[i + 1] >= e_ts[i] - 1e-9 for i in range(len(ts) - 1)) and e_ts[-1] > e_ts[0] + 1e-3
    v = e_ts[-1]
    status = "PASS" if mono else "FAIL"
    add("B8", "Editing accumulates monotonically over 24/48/72 h",
        "Han 2022: editing increases with assay duration and dose",
        "edited-112 fraction @72h", v, "monotone increasing", status,
        "consistency check",
        f"24h={e_ts[0]:.4f}, 48h={e_ts[1]:.4f}, 72h={e_ts[2]:.4f}")

    # ------------------------------------------------------------------ out
    n_pass = sum(1 for r in results if r["status"] == "PASS")
    n_part = sum(1 for r in results if r["status"] == "PARTIAL")
    n_fail = sum(1 for r in results if r["status"] == "FAIL")
    summary = {
        "n_benchmarks": len(results),
        "n_pass": n_pass,
        "n_partial": n_part,
        "n_fail": n_fail,
        "score": f"{n_pass}/{len(results)} PASS, {n_part} PARTIAL, {n_fail} FAIL",
        "time_course_24_48_72": e_ts,
    }

    csv_path = out_dir / "benchmark_scorecard.csv"
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(results[0].keys()))
        writer.writeheader()
        writer.writerows(results)

    md_path = out_dir / "benchmark_scorecard.md"
    with open(md_path, "w", encoding="utf-8") as f:
        f.write("# CU-REWIRE benchmark scorecard (model v4, transfection mode)\n\n")
        f.write(f"**Score: {summary['score']}**\n\n")
        f.write("| ID | Benchmark | Literature anchor | Model value | Target | Status | Test type |\n")
        f.write("|----|-----------|-------------------|-------------|--------|--------|-----------|\n")
        for r in results:
            f.write(f"| {r['benchmark_id']} | {r['benchmark']} | {r['literature_anchor']} "
                    f"| {r['model_value']} | {r['target']} | {r['status']} | {r['test_type']} |\n")
        f.write("\n")
        for r in results:
            f.write(f"- **{r['benchmark_id']}** {r['detail']}\n")

    import json
    with open(out_dir / "benchmark_summary.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)

    print(f"\nScore: {summary['score']}")
    print(f"CSV: {csv_path}")
    print(f"MD:  {md_path}")


if __name__ == "__main__":
    main()
