"""Check all delivered hashes; does not import or execute any scientific model."""
from pathlib import Path
import hashlib
root = Path(__file__).resolve().parent
count = 0
for line in (root / "SHA256SUMS").read_text().splitlines():
    digest, relative = line.split("  ", 1)
    path = root / relative
    assert path.is_file(), relative
    assert hashlib.sha256(path.read_bytes()).hexdigest() == digest, relative
    count += 1
print(f"Verified {count} files; all SHA-256 hashes match.")
