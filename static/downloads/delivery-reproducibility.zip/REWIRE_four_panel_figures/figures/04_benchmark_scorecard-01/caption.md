Panels: A: B1 · PASS; B: B2 · PASS; C: B3 · PASS; D: B4 · PARTIAL.

F6 benchmark scorecard, retaining all eight saved model values and PASS/PARTIAL/FAIL statuses. Green bands = source PASS display range; orange bands = source PARTIAL display range. Each panel has its own actual numeric axis. B6 is displayed in full at 460.937, without clamping to 5. B8 band is the original display convention; its source criterion is monotonic accumulation. This redraw does not independently validate the literature anchors or benchmark definitions.
