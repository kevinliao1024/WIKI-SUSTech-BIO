Panels: A: APOE RNA fraction, 168 h; B: On-target editing rate; C: Off-target burden; D: Specificity index.

Coarse and fine dose scans, including the F1 product fractions and all 14 original dose-response figures. Existing feasibility flags are retained. F1 vertical lines: efficacy crossing 0.127421, off-target crossing 0.168078, product-mix inversion 3.19008; linear interpolation as in the source plotting script. Dose axes are logarithmic for readability; all values are retained. Circle = coarse; square = fine. The supplied thresholds are model criteria, not validated clinical boundaries.
