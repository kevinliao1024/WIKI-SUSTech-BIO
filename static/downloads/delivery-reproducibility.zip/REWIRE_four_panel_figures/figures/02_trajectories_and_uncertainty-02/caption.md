Four uncertainty distributions from 200 frozen parameter samples (seed 7) for 10R-proapobec, dose 0.9, 168 h. Shading is the 5th–95th parameter-sample interval; solid lines are medians and dashed lines are existing criteria. These are model uncertainty intervals, not experimental confidence intervals. Positive values are displayed without clipping.
APOE3-like fraction: median 0.0837548; p05–p95 0.00162004–0.740191; P(meets criterion) 0.23
Specificity index: median 8.2032; p05–p95 2.89873–9.53152; P(meets criterion) 0.86
LDLR-binding risk proxy: median 1.10444e-05; p05–p95 4.11049e-09–0.00814138; P(meets criterion) 0.96
Off-target burden: median 0.0103819; p05–p95 0.000172482–0.162409
