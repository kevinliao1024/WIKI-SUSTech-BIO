Panels: A: Legacy NB06; B: Legacy NB07.

Seven legacy notebook images consolidated into six panels: the two identical editing-fraction plots appear once. Re-executed only after user approval with original parameters, RK45/default tolerances and original 20×20 parameter grid. This is an early simplified model, distinct from the v4 multisite model; no v4 biological inference should be drawn from the legacy product label. Heatmap retains source extent and orientation; color changed to ORCA sequential purple. No parameters or statistical methods changed.
