"""Original native-vector workflow icons. No model, dataset, or image generation."""
from pathlib import Path
import sys,json,hashlib,platform
import xml.etree.ElementTree as ET
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import Circle,Ellipse,Rectangle,Polygon,PathPatch,FancyArrowPatch,FancyBboxPatch
from matplotlib.path import Path as MPath
from matplotlib.transforms import Affine2D

ROOT=Path(__file__).resolve().parent
OUT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT
OUT.mkdir(parents=True,exist_ok=True)
dest={ext:OUT/f'icon-workflow.{ext}' for ext in ['svg','png','pdf']}
if any(p.exists() for p in dest.values()):
    raise FileExistsError('Use a new/versioned output directory')
C={'ink':'#171536','purple':'#2E267C','violet':'#5D5AD7','lavender':'#E9E8FF','light':'#9D9CF4','orange':'#E89B3C','teal':'#27877F','coral':'#F58F9C','coral_light':'#FFD1D5','muted':'#6B6880','line':'#D9D7E5'}
installed={f.name for f in font_manager.fontManager.ttflist}
font=next(f for f in ['Futura','Arial','DejaVu Sans'] if f in installed)
plt.rcParams.update({'font.family':[font,'Arial','DejaVu Sans'],'font.weight':'medium','svg.fonttype':'none','pdf.fonttype':42,'text.color':C['ink'],'figure.facecolor':'white'})
fig,ax=plt.subplots(figsize=(14,5.8))
fig.subplots_adjust(0,0,1,1)
ax.set(xlim=(0,1400),ylim=(580,0));ax.axis('off')

def path(vertices,codes=None,fill='none',stroke=None,lw=2.8,alpha=1,transform=None):
    p=PathPatch(MPath(vertices,codes),facecolor=fill,edgecolor=stroke or C['purple'],linewidth=lw,joinstyle='round',capstyle='round',alpha=alpha,transform=transform or ax.transData)
    ax.add_patch(p);return p

def polyline(points,color=None,lw=2.8,transform=None):
    return path(points,[MPath.MOVETO]+[MPath.LINETO]*(len(points)-1),stroke=color,lw=lw,transform=transform)

def circle(x,y,r,fill='white',stroke=None,lw=2.8):
    a=Circle((x,y),r,facecolor=fill,edgecolor=stroke or C['purple'],linewidth=lw);ax.add_patch(a);return a

def arrow(start,end,rad=0,color=None,lw=2.5):
    a=FancyArrowPatch(start,end,arrowstyle='-|>',mutation_scale=15,connectionstyle=f'arc3,rad={rad}',linewidth=lw,color=color or C['purple'],shrinkA=0,shrinkB=0,zorder=1)
    ax.add_patch(a);return a

def label(x,y,lines):
    return ax.text(x,y,lines,ha='center',va='top',fontsize=21,linespacing=1.25,color=C['ink'])

def syringe(x,y):
    tr=Affine2D().rotate_deg(-35).translate(x,y)+ax.transData
    ax.add_patch(Rectangle((-17,-40),34,63,facecolor=C['lavender'],edgecolor=C['purple'],linewidth=2.8,transform=tr))
    polyline([(-25,-43),(25,-43)],transform=tr)
    polyline([(0,-43),(0,-68)],transform=tr)
    polyline([(-18,-68),(18,-68)],transform=tr)
    ax.add_patch(Rectangle((-17,0),34,23,facecolor=C['light'],edgecolor='none',transform=tr,alpha=.7))
    for yy in [-25,-12,2]:polyline([(5,yy),(17,yy)],lw=2,transform=tr)
    polyline([(-8,23),(-8,36),(8,36),(8,23)],transform=tr)
    polyline([(0,36),(0,62)],transform=tr)
    # A local depot represents administered material without specifying a route.
    ax.add_patch(Ellipse((x+37,y+54),60,23,facecolor=C['lavender'],edgecolor='none'))
    for xx,yy,rr in [(x+21,y+49,5),(x+37,y+56,6),(x+51,y+48,4)]:circle(xx,yy,rr,fill=C['orange'],stroke=C['orange'],lw=1)

def distribution(x,y):
    # Heart and vascular branches are schematic distribution symbols.
    v=[(x,y-4),(x-12,y-19),(x-56,y-39),(x-43,y-62),(x-30,y-84),(x-7,y-77),(x,y-59),(x+7,y-77),(x+30,y-84),(x+43,y-62),(x+56,y-39),(x+12,y-19),(x,y-4)]
    path(v,[MPath.MOVETO]+[MPath.CURVE4]*12,fill=C['lavender'])
    polyline([(x,y-4),(x,y+23),(x-49,y+23),(x-49,y+48)])
    polyline([(x,y+23),(x+49,y+23),(x+49,y+48)])
    polyline([(x,y+23),(x,y+55)])
    for xx,yy in [(x-49,y+57),(x,y+65),(x+49,y+57)]:circle(xx,yy,10,fill='white')
    circle(x,y-27,6,fill=C['orange'],stroke=C['orange'],lw=1)

def barrier(x,y):
    # Endothelial layer, junctions, and a transport symbol; no route is inferred.
    polyline([(x-64,y-49),(x+64,y-49)],color=C['light'],lw=3)
    polyline([(x-64,y+43),(x+64,y+43)],color=C['light'],lw=3)
    for xx in [x-59,x-19,x+21]:
        cell=FancyBboxPatch((xx,y-24),38,46,boxstyle='round,pad=0,rounding_size=8',facecolor=C['lavender'],edgecolor=C['purple'],linewidth=2.5)
        ax.add_patch(cell);ax.add_patch(Ellipse((xx+19,y-1),15,9,facecolor=C['light'],edgecolor='none'))
    for xx in [x-20,x+20]:polyline([(xx,y-15),(xx,y+15)],color=C['purple'],lw=4)
    for xx in [x-42,x+3,x+44]:circle(xx,y-63,5,fill=C['purple'],stroke=C['purple'],lw=1)
    arrow((x+45,y-38),(x+45,y+33),color=C['orange'],lw=3.5)
    circle(x+45,y+62,6,fill=C['orange'],stroke=C['orange'],lw=1)

def rna(x,y,color=None,scale=1,editing=False):
    color=color or C['purple']
    pts=[(-58,0),(-40,-12),(-23,8),(-5,-9),(13,10),(31,-7),(49,6),(62,-3)]
    polyline([(x+px*scale,y+py*scale) for px,py in pts],color=color,lw=3)
    for i,(px,py) in enumerate(pts[1:-1]):
        circle(x+px*scale,y+py*scale,4.5*scale,fill=C['orange'] if editing and i==3 else 'white',stroke=color,lw=2)

def protein(x,y,color=None,scale=1):
    color=color or C['purple']
    verts=[(-20,-2),(-21,-17),(-4,-24),(6,-10),(21,-14),(28,2),(14,11),(18,25),(-2,25),(-7,12),(-25,13),(-20,-2)]
    path([(x+a*scale,y+b*scale) for a,b in verts],[MPath.MOVETO]+[MPath.CURVE3]*10+[MPath.LINETO],fill=C['lavender'],stroke=color,lw=2.5)

def expression(x,y):
    ax.add_patch(Ellipse((x,y),132,132,facecolor='white',edgecolor=C['purple'],linewidth=2.8))
    ax.add_patch(Ellipse((x-27,y-19),47,50,angle=-20,facecolor=C['lavender'],edgecolor=C['light'],linewidth=2))
    rna(x-2,y+28,scale=.62)
    protein(x+27,y-20,scale=.8)
    arrow((x+3,y+12),(x+24,y-2),color=C['orange'],lw=2.5)

def pencil(x,y,color=None):
    color=color or C['purple'];tr=Affine2D().rotate_deg(35).translate(x,y)+ax.transData
    ax.add_patch(Rectangle((-7,-33),14,45,facecolor='white',edgecolor=color,linewidth=2.5,transform=tr))
    ax.add_patch(Rectangle((-7,-33),14,10,facecolor=C['lavender'],edgecolor=color,linewidth=2,transform=tr))
    ax.add_patch(Polygon([(-7,12),(7,12),(0,27)],closed=True,facecolor=C['orange'],edgecolor=color,linewidth=2,transform=tr))

def editing(x,y,unintended=False):
    col=C['coral'] if unintended else C['purple']
    rna(x,y+25,color=col,editing=not unintended)
    pencil(x+10,y-17,color=col)
    if unintended:
        # A second marked RNA position differentiates the unintended branch.
        circle(x-23,y+33,8,fill=C['coral_light'],stroke=C['coral'],lw=2)
        circle(x+31,y+18,8,fill=C['coral_light'],stroke=C['coral'],lw=2)
    else:
        circle(x+13,y+35,11,fill='#FFF1DB',stroke=C['orange'],lw=2.2)

def comparison(x,y):
    # Generic chart icon; its strokes are symbolic and encode no measured data.
    polyline([(x-59,y-57),(x-59,y+55),(x+62,y+55)],lw=3)
    for xx,hh,col in [(x-42,40,C['light']),(x-9,67,C['orange']),(x+24,91,C['purple'])]:
        ax.add_patch(Rectangle((xx,y+55-hh),20,hh,facecolor=col,edgecolor='none'))
    polyline([(x-45,y-48),(x-27,y-35),(x-8,y-51),(x+12,y-42),(x+37,y-61)],color=C['teal'],lw=3)

# Seven directed relationships copied from the source model workflow.
for a,b in [((182,250),(242,250)),((392,250),(452,250)),((602,250),(662,250))]:arrow(a,b)
arrow((807,233),(904,147),rad=-.12)
arrow((807,267),(904,412),rad=.15)
arrow((1048,147),(1174,233),rad=-.10)
arrow((1048,412),(1174,267),rad=.10)
syringe(105,250);distribution(315,250);barrier(525,250);expression(735,250)
editing(975,145);editing(975,415,unintended=True);comparison(1245,250)
texts=[label(105,347,'Administration'),label(315,347,'Tissue\ndistribution'),label(525,347,'BBB\ntransport'),label(735,347,'Cellular\nexpression'),label(975,232,'APOE editing'),label(975,493,'Unintended\nediting'),label(1245,347,'Model\ncomparison')]

fig.canvas.draw();renderer=fig.canvas.get_renderer()
for i,t in enumerate(texts):
    for u in texts[i+1:]:assert not t.get_window_extent(renderer).overlaps(u.get_window_extent(renderer))
    assert fig.bbox.contains(*t.get_window_extent(renderer).get_points()[0])
    assert fig.bbox.contains(*t.get_window_extent(renderer).get_points()[1])
for ext,p in dest.items():fig.savefig(p,format=ext,dpi=1920/14,facecolor='white',bbox_inches=None)
plt.close(fig)
xml=ET.parse(dest['svg']).getroot();images=sum(n.tag.rsplit('}',1)[-1]=='image' for n in xml.iter())
assert images==0
report={'renderer':'Matplotlib Agg','python':platform.python_version(),'matplotlib':matplotlib.__version__,'font':font,'fallbacks':['Arial','DejaVu Sans'],'canvas_px':[1400,580],'png_width_px':1920,'native_svg_text':True,'svg_image_nodes':images,'stage_count':7,'directed_edges':[['Administration','Tissue distribution'],['Tissue distribution','BBB transport'],['BBB transport','Cellular expression'],['Cellular expression','APOE editing'],['Cellular expression','Unintended editing'],['APOE editing','Model comparison'],['Unintended editing','Model comparison']],'model_recomputed':False,'process_labels_in_separate_boxes':False,'graphic_statistics':'The comparison icon is symbolic and contains no data or numeric claims.'}
(OUT/'validation.json').write_text(json.dumps(report,indent=2))
print(json.dumps({'svg':str(dest['svg']),'png':str(dest['png']),'svg_image_nodes':images,'stages':7}))
