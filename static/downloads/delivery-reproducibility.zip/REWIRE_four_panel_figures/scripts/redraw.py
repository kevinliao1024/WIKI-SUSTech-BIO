"""Replot frozen REWIRE arrays; never rerun scientific models or alter thresholds."""
from pathlib import Path
import sys,json,hashlib,math,textwrap,copy
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import MaxNLocator
from matplotlib.colors import LinearSegmentedColormap
from orca_plot import Theme,export
ROOT=Path(__file__).resolve().parents[1]; D=ROOT/'data'
OUT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT/'figures'
OUT.mkdir(parents=True,exist_ok=True)
theme=Theme(OUT/'orca-figure-style.json')
theme.config['text'].update(label_pt=19,tick_pt=17,legend_pt=17,annotation_pt=18)
theme.config['figure']['display_width_px']=960
theme.config['group_styles']={'dose 0.5':{'color':'#2E267C','marker':'o'},'dose 2.0':{'color':'#E89B3C','marker':'s'},'archived baseline':{'color':'#27877F','marker':'^'},'APOE3-like':{'color':'#27877F','marker':'o'},'APOE2-like':{'color':'#F58F9C','marker':'s'}}
theme.save(); C=theme.c; purple=C['indigo700'];orange=C['orange500'];teal=C['teal600'];coral=C['coral400'];muted=C['muted']
records=[]
def read(f):return pd.read_csv(D/f)
class PanelPages:
 """Each scientific panel is drawn directly into a separate <=4-panel figure."""
 def __init__(self, figures): self.figures=figures
 def legend(self, *args, **kwargs):
  kwargs['fontsize']=17
  for figure in self.figures: figure.legend(*args,**kwargs)
 def colorbar(self, *args, ax=None, **kwargs):
  return ax.figure.colorbar(*args,ax=ax,**kwargs)
def grid(n, chunks=None):
 chunks=chunks or [min(4,n-i) for i in range(0,n,4)]
 assert sum(chunks)==n and max(chunks)<=4
 figures=[];axes=[]
 for count in chunks:
  rows=math.ceil(count/2);cols=min(count,2)
  fig,aa=plt.subplots(rows,cols,figsize=(13.5 if cols==2 else 7.5,4.7*rows+.55),layout='constrained',squeeze=False)
  fig.set_constrained_layout_pads(w_pad=.14,h_pad=.16,wspace=.10,hspace=.14)
  for a in aa.flat[count:]:a.remove()
  fig._panel_axes=list(aa.flat[:count]);figures.append(fig);axes.extend(fig._panel_axes)
 return PanelPages(figures),axes
def label(ax,s):
 ax._short_label=s
 ax.text(.02,.98,textwrap.fill(s,30),transform=ax.transAxes,va='top',fontsize=17,color=C['ink'],bbox={'facecolor':'white','edgecolor':'none','alpha':.9,'pad':2})
def finish(pages,name,caption,sources,data=None):
 for page,fig in enumerate(pages.figures,1):
  slug=f'{name}-{page:02d}'
  panel_specs=[]
  for any_ax in fig.axes:
   for artist in any_ax.collections:artist.set_rasterized(False)
  for i,ax in enumerate(fig._panel_axes):
   letter=chr(65+i)
   ax.text(-.15,1.04,letter,transform=ax.transAxes,va='bottom',ha='left',fontsize=24,color=C['ink'])
   for artist in ax.collections:artist.set_rasterized(False)
   if ax.get_xscale()=='linear' and len(ax.get_xticks())>6:ax.xaxis.set_major_locator(MaxNLocator(nbins=4))
   ax.set_xlabel(textwrap.fill(ax.get_xlabel(),34))
   ax.set_ylabel(textwrap.fill(ax.get_ylabel(),32))
   panel_specs.append({'label':letter,'metric':getattr(ax,'_metric',getattr(ax,'_short_label',ax.get_ylabel())), 'xlabel':ax.get_xlabel(),'ylabel':ax.get_ylabel(),'kind':getattr(ax,'_source_kind',''),'line_count':len(ax.lines),'line_points':sum(len(line.get_xdata()) for line in ax.lines)})
  if name=='03_sensitivity_design_spatial':
   fig._panel_axes[0].tick_params(axis='y',labelsize=16)
  pagecaption='Panels: '+ '; '.join(p['label']+': '+p['metric'].replace('\n',' ') for p in panel_specs)+'.\n\n'+caption
  if name=='02_trajectories_and_uncertainty':
   pagecaption=('Two saved v4 trajectories: dose 0.5 and dose 2.0, both 168 h. Fractions are normalized by the recorded total APOE RNA pool.' if page==1 else 'Four uncertainty distributions from 200 frozen parameter samples (seed 7) for 10R-proapobec, dose 0.9, 168 h. Shading is the 5th–95th parameter-sample interval; solid lines are medians and dashed lines are existing criteria. These are model uncertainty intervals, not experimental confidence intervals. Positive values are displayed without clipping.\n'+'\n'.join(captions))
  paths=export(fig,OUT/slug,theme,caption=pagecaption,alt_text=pagecaption.split('\n')[0],provenance={'inputs':[{'path':s,'sha256':hashlib.sha256((D/s).read_bytes()).hexdigest()} for s in sources], 'processing':'Display-only regrouping of frozen arrays. Original points, model criteria, saved statuses and analysis methods retained. No model recomputation; all results are model predictions.', 'grouping':'Maximum four scientific panels per independent figure; duplicate source views consolidated.','panels':panel_specs})
  if data is not None:
   dd=data
   if 'metric' in data.columns:dd=data[data.metric.isin([p['metric'] for p in panel_specs])]
   dd.to_csv(OUT/slug/'plotted-data.csv',index=False)
  records.append({'id':slug,'previous_group':name,'svg':str(Path(paths['svg']).relative_to(ROOT)),'png':str(Path(paths['png']).relative_to(ROOT)),'pdf':str(Path(paths['pdf']).relative_to(ROOT)),'panel_count':len(panel_specs),'panels':panel_specs,'caption':pagecaption,'sources':sources,'main_page_eligible':True})
  print('saved',slug,flush=True);plt.close(fig)
def simple(ax,x,y,xlabel,ylabel,color=purple,marker=None):
 assert np.isfinite(np.asarray(x)).all() and np.isfinite(np.asarray(y)).all()
 ax.plot(x,y,color=color,lw=2.3,marker=marker,ms=5);ax.set(xlabel=xlabel,ylabel=ylabel);ax.margins(y=.12);ax.ticklabel_format(axis='y',style='sci',scilimits=(-3,4),useMathText=True)
with theme.context():
 coarse=read('new_results/module6_v4_dose_scan/module6_dose_scan.csv');fine=read('new_results/module6_v4_dose_scan_fine/module6_dose_scan.csv')
 fig,axes=grid(8);ax=axes[0]
 for m,col,marker,lab in [('apoe3_like_fraction_final',teal,'o','APOE3-like'),('apoe2_like_fraction_final',coral,'s','APOE2-like')]:
  ax.plot(coarse.dose,coarse[m],marker=marker,color=col,label=lab);ax.plot(fine.dose,fine[m],marker=marker,color=col,ls='none',ms=4,alpha=.7)
 ax.set(xscale='log',xlabel='Dose (model units)',ylabel='APOE RNA fraction, 168 h');ax.legend(loc='upper left');ax.set_ylim(0,1.05)
 allv=pd.concat([coarse,fine]).sort_values('dose').drop_duplicates('dose')
 eff=float(np.interp(.2,allv.on_target_editing_rate_final,allv.dose));off=float(np.interp(.05,allv.off_target_burden_final,allv.dose))
 seg=coarse[(coarse.dose>=2.8)&(coarse.dose<=3.7)];cross=float(np.interp(0,(seg.apoe3_like_fraction_final-seg.apoe2_like_fraction_final).to_numpy()[::-1],seg.dose.to_numpy()[::-1]))
 for v,col,ls in [(eff,teal,':'),(off,coral,':'),(cross,muted,'--')]:ax.axvline(v,color=col,ls=ls,lw=1.4)
 specs=[('on_target_editing_rate_final','On-target editing rate'),('off_target_burden_final','Off-target burden'),('specificity_index_final','Specificity index'),('AUC_liver','Liver AUC (model units)'),('Cmax_blood','Blood Cmax (model units)'),('P_brain_peak','Peak brain expression')]
 for ax,(m,lab) in zip(axes[1:7],specs):
  ax.plot(coarse.dose,coarse[m],'-o',color=purple,label='Coarse scan',ms=5);ax.plot(fine.dose,fine[m],'s',color=orange,label='Fine scan',ms=4)
  ax.set(xscale='log',xlabel='Dose (model units)',ylabel=lab);ax.legend();ax.margins(y=.15)
 ax=axes[7]
 for df,marker in [(coarse,'o'),(fine,'s')]:
  for feas,col in [(True,teal),(False,coral)]:
   s=df[df.feasible==feas];ax.scatter(s.dose,s.on_target_editing_rate_final,color=col,marker=marker,s=42)
 ax.set(xscale='log',xlabel='Dose (model units)',ylabel='On-target editing rate')
 ax.legend(handles=[Line2D([],[],marker='o',ls='',color=teal,label='Feasible'),Line2D([],[],marker='o',ls='',color=coral,label='Not feasible')])
 finish(fig,'01_dose_response',f'Coarse and fine dose scans, including the F1 product fractions and all 14 original dose-response figures. Existing feasibility flags are retained. F1 vertical lines: efficacy crossing {eff:.6g}, off-target crossing {off:.6g}, product-mix inversion {cross:.6g}; linear interpolation as in the source plotting script. Dose axes are logarithmic for readability; all values are retained. Circle = coarse; square = fine. The supplied thresholds are model criteria, not validated clinical boundaries.', ['new_results/module6_v4_dose_scan/module6_dose_scan.csv','new_results/module6_v4_dose_scan_fine/module6_dose_scan.csv'],pd.concat([coarse.assign(scan='coarse'),fine.assign(scan='fine')]))
 # F2 and F7: distinct model configurations remain explicitly separate.
 fig,axes=grid(6,chunks=[2,4])
 sources=[]
 for ax,run,dose in zip(axes[:2],['run_dose0p5_t168','run_dose2_t168'],[.5,2]):
  f=f'new_results/{run}/simulation_results.npz';sources.append(f);z=np.load(D/f,allow_pickle=True);idx={s:i for i,s in enumerate(z['state_order'])}; names=['S_APOE4','S_APOE3_like','S_APOE2_like','S_APOE158_only'];pool=sum(z['y'][idx[s]] for s in names)
  for s,col,lab,ls in zip(names,[muted,teal,coral,orange],['APOE4','APOE3-like','APOE2-like','158-only'],['-','-','-','--']):ax.plot(z['t'],z['y'][idx[s]]/pool,color=col,label=lab,ls=ls)
  ax.set(xlabel='Time (h)',ylabel='APOE RNA fraction',ylim=(0,1.1));ax._short_label=f'Dose {dose:g}'
  ax.text(.5,1.045,f'Dose {dose:g}',transform=ax.transAxes,ha='center',va='bottom',fontsize=18,color=C['ink'])
 fig.figures[0].set_size_inches(13.5,5.95)
 handles,legend_labels=axes[0].get_legend_handles_labels()
 fig.figures[0].legend(handles,legend_labels,loc='outside lower center',ncol=4,fontsize=17,frameon=False,columnspacing=1.8,handlelength=2.5)

 df=read('new_results/design_uncertainty/design_uncertainty_samples.csv');S=json.loads((D/'new_results/design_uncertainty/design_uncertainty_summary.json').read_text())
 specs=[('apoe3_like_fraction_final','APOE3-like fraction',False,teal),('specificity_index_final','Specificity index',False,purple),('ldlr_binding_risk_proxy_final','LDLR-binding risk proxy',True,coral),('off_target_burden_final','Off-target burden',True,orange)]
 captions=[]
 for ax,(m,lab,log,col) in zip(axes[2:],specs):
  x=df[m].to_numpy();assert np.isfinite(x).all();e=S['metrics'][m]
  bins=np.geomspace(x.min(),x.max(),29) if log else np.linspace(min(0,x.min()),max(1,x.max())*1.001,29)
  counts,_=np.histogram(x,bins);assert counts.sum()==len(x)
  ax.hist(x,bins=bins,color=col,edgecolor='white',lw=.5,alpha=.8);ax.axvspan(e['p05'],e['p95'],color=col,alpha=.12);ax.axvline(e['median'],color=C['ink'],lw=2,label='Median')
  if log:ax.set_xscale('log')
  if 'criterion_threshold' in e:ax.axvline(e['criterion_threshold'],color=teal if col==coral else coral,ls='--',label='Criterion')
  ax._metric=lab;ax.set(xlabel=lab,ylabel='Parameter samples');ax.legend(loc='upper left' if m in ['specificity_index_final','ldlr_binding_risk_proxy_final'] else 'upper right');captions.append(f"{lab}: median {e['median']:.6g}; p05–p95 {e['p05']:.6g}–{e['p95']:.6g}"+ (f"; P(meets criterion) {e['prob_meet_criterion']:.2f}" if 'prob_meet_criterion' in e else ''))
 sources+=['new_results/design_uncertainty/design_uncertainty_samples.csv','new_results/design_uncertainty/design_uncertainty_summary.json']
 finish(fig,'02_trajectories_and_uncertainty','Top: F2 saved trajectories. Lower four panels: F7 uncertainty for 10R-proapobec, dose 0.9, 168 h, 200 archived parameter samples (seed 7); a different configuration from the top panels. Shading is the 5th–95th parameter-sample percentile interval, not experimental confidence intervals. Log panels retain all positive original values without the original 1e-10 clipping.\n'+'\n'.join(captions),sources,df)
 # F3-F5 grouped comparisons.
 fig,axes=grid(4);s=read('archive/outputs/sensitivity_analysis/local_sensitivity_results.csv');s=s[s.scale==1.2].copy();s['abs']=s.specificity_index_final_sens.abs();top=s.sort_values('abs',ascending=False).head(10).iloc[::-1];ax=axes[0]
 ax.barh(top.parameter,top.specificity_index_final_sens,color=[coral if v<0 else teal for v in top.specificity_index_final_sens]);ax.axvline(0,color=muted);ax.set_xlabel('Specificity sensitivity (parameter ×1.2)');ax.margins(x=.22)
 for i,v in enumerate(top.specificity_index_final_sens):ax.text(v+(.012 if v>=0 else -.012),i,f'{v:+.2f}',ha='left' if v>=0 else 'right',va='center',fontsize=16)
 g=read('archive/reports/iterated_analysis/v4_design_screen.csv');g=g[g.sample_time_h==72];ax=axes[1];ids=list(dict.fromkeys(g.design_id));palette=[purple,orange,teal,coral,C['lavender300'],C['indigo500'],C['ink'],muted]
 for j,design in enumerate(ids):
  rows=g[g.design_id==design]
  for _,r in rows.iterrows():ax.scatter(r.apoe2_like_fraction_final,r.apoe3_like_fraction_final,s=60+20000*r.off_target_burden_final,marker='s' if r.editor_type=='ProAPOBEC' else 'o',color=palette[j%len(palette)],alpha=.8,edgecolors='white');ax.annotate(str(j+1)+{'low':'L','medium':'M','high':'H'}.get(r.dose_level,r.dose_level[:1].upper()),(r.apoe2_like_fraction_final,r.apoe3_like_fraction_final),xytext=(5,5),textcoords='offset points',fontsize=14)
 ax.set(xscale='log',xlabel='APOE2-like fraction',ylabel='APOE3-like fraction');ax.margins(x=.15,y=.2)
 fm=json.loads((D/'archive/outputs/physicell_brain_delivery/scientific_checks.json').read_text())['final_spatial_metrics'];doses=[.3,1.,3.];vals={k:[fm['dose_'+str(v).replace('.','p')][k] for v in doses] for k in next(iter(fm.values())) if k.endswith('mean')}
 ax=axes[2]
 for k,col,m,lab in [('near_vessel_editing_mean',purple,'o','Near vessel'),('far_vessel_editing_mean',C['lavender300'],'s','Far vessel')]:ax.plot(doses,vals[k],marker=m,color=col,label=lab)
 ax.set(xscale='log',yscale='log',xlabel='Dose (model units)',ylabel='Mean editing fraction, 72 h');ax.legend()
 ax=axes[3]
 for k,col,m,lab in [('astrocyte_editing_mean',orange,'o','Astrocytes'),('neuron_editing_mean',C['indigo500'],'s','Neurons')]:ax.plot(doses,vals[k],marker=m,color=col,label=lab)
 ax.plot(doses,np.array(doses)*vals['neuron_editing_mean'][1],':',color=muted,label='Proportional to dose');ax.set(xscale='log',yscale='log',xlabel='Dose (model units)',ylabel='Mean editing fraction, 72 h');ax.legend()
 for a,m in zip(axes,['Local sensitivity','Design comparison at 72 h','Distance from vessel','Cell-type comparison']):a._metric=m
 finish(fig,'03_sensitivity_design_spatial','F3–F5 comparisons. Top left retains the source top-10 absolute sensitivity ranking at scale 1.2. Top right: all 72 h design-screen rows; marker area = 60 + 20000 × off-target burden; square = ProAPOBEC, circle = A3A; suffix L/M/H denotes source dose category. Design IDs: '+ '; '.join(f'{j+1}: {v}' for j,v in enumerate(ids))+'. Bottom: archived spatial summary means, without invented error bars. Near/far means are shown as points on a log axis rather than bars with an undefined zero baseline.', ['archive/outputs/sensitivity_analysis/local_sensitivity_results.csv','archive/reports/iterated_analysis/v4_design_screen.csv','archive/outputs/physicell_brain_delivery/scientific_checks.json'])
 # Benchmark uses per-row true axes; retains original judgement/target bands.
 b=read('new_results/benchmarks/benchmark_scorecard.csv');fig,axes=grid(8)
 rows=[('B1',.02,(0,.001),(.001,.01),'Inactive-deaminase control'),('B2',.02,(0,.001),(.001,.01),'PUF-only control'),('B3',1.05,(.2,1.05),(.05,.2),'Preferred-design editing'),('B4',.6,(0,.2),(.2,.5),'Editing(+7) / editing(+2)'),('B5',26,(5,18),(2.5,25),'Editing(UC) / editing(CC)'),('B6',500,(3,500),(1.5,3),'Mismatch burden: 8R / 10R'),('B7',4,(1,4),None,'Background: dose 2 / dose 0.5'),('B8',1.05,(.9,1.05),None,'Edited-112 fraction, 72 h')]
 for ax,(bid,maxv,p,w,lab) in zip(axes,rows):
  r=b[b.benchmark_id==bid].iloc[0];v=float(r.model_value)
  if w:ax.axvspan(*w,color=orange,alpha=.17)
  ax.axvspan(*p,color=teal,alpha=.2);ax.plot(v,.5,'D',ms=12,color={'PASS':teal,'PARTIAL':orange,'FAIL':coral}[r.status]);ax.set(xlim=(-maxv*.03,maxv*1.06),ylim=(0,1),yticks=[],xlabel=lab)
  label(ax,f'{bid} · {r.status}');ax.text(.97,.9,f'{v:.6g}',transform=ax.transAxes,ha='right',va='top',fontsize=20)
 finish(fig,'04_benchmark_scorecard','F6 benchmark scorecard, retaining all eight saved model values and PASS/PARTIAL/FAIL statuses. Green bands = source PASS display range; orange bands = source PARTIAL display range. Each panel has its own actual numeric axis. B6 is displayed in full at 460.937, without clamping to 5. B8 band is the original display convention; its source criterion is monotonic accumulation. This redraw does not independently validate the literature anchors or benchmark definitions.', ['new_results/benchmarks/benchmark_scorecard.csv'],b)
 # Group all module plots by metric, overlay conditions. Exact duplicates are consolidated.
 runs=['run_dose0p5_t168','run_dose2_t168','wiki_assets'];conditions=['Dose 0.5','Dose 2.0','Archived baseline'];cols=[purple,orange,teal];styles=['-','--',':']
 aliases={'module1_states':'module1_absorption_states','module2_states':'module2_distribution_states','module3_states':'module3_bbb_transport_states','module4_states':'module4_expression_states','module5_states':'apoe_multisite_editing_states','module5_fluxes':'apoe_editing_fluxes','module5_metrics':'apoe_editing_metrics','combined_states':'full_chain_state_overview'}
 def loadsets(kind):
  sets=[]
  for run in runs:
   n=aliases.get(kind,kind) if run=='wiki_assets' else kind;f=f'plot_series/{run}/{n}.json';p=D/f
   sets.append((f,json.loads(p.read_text())) if p.exists() else None)
  return sets
 groups=[(f'{i+4:02}_module{i}',[f'module{i}_states',f'module{i}_fluxes']) for i in range(1,5)]
 groups += [('09_module5_states',['module5_states']),('10_module5_metrics',['module5_metrics']),('11_module5_fluxes_a',['module5_fluxes']),('12_module5_fluxes_b',['module5_fluxes'])]
 for name,kinds in groups:
  specs=[];sources=[]
  for kind in kinds:
   sets=loadsets(kind);names=[s['name'] for s in sets[0][1]['series']]
   if name.endswith('fluxes_a'):names=names[:13]
   if name.endswith('fluxes_b'):names=names[13:]
   if kind=='module5_metrics':names=[n for n in names if n not in ['on_target_editing_fraction','ldlr_binding_risk_proxy']]
   for n in names:specs.append((kind,n,sets))
   sources.extend(v[0] for v in sets if v)
  fig,axes=grid(len(specs));table=[]
  for ax,(kind,n,sets) in zip(axes,specs):
   ax._metric=n;ax._source_kind=kind
   for j,item in enumerate(sets):
    if not item:continue
    f,dd=item;s=next((v for v in dd['series'] if v['name']==n),None)
    if not s:continue
    x=np.array(s['x']);y=np.array(s['y']);assert np.isfinite(x).all() and np.isfinite(y).all()
    ax.plot(x,y,color=cols[j],ls=styles[j],lw=2.3,label=conditions[j]);table.extend({'metric':n,'condition':conditions[j],'time_h':xx,'value':yy} for xx,yy in zip(x,y))
   ax.set(xlabel='Time (h)',ylabel='Flux' if 'fluxes' in kind else 'Metric' if 'metrics' in kind else 'Amount / level');label(ax,n.replace('_',' '));ax.margins(y=.25);ax.ticklabel_format(axis='y',style='sci',scilimits=(-3,4),useMathText=True)
   ax.set_xlim(0,168);ax.set_xticks([0,48,96,168])
  fig.legend(handles=[Line2D([],[],color=c,ls=ls,lw=2.5,label=lab) for c,ls,lab in zip(cols,styles,conditions) if lab!='Archived baseline' or any(s[2][2] for s in specs)],loc='outside lower center',ncol=3,fontsize=20)
  finish(fig,name,'Saved model trajectories grouped by metric. Purple solid = dose 0.5; orange dashed = dose 2.0; teal dotted = archived baseline where available. Baseline may have a shorter recorded time domain; no extrapolation. All original points are retained. Mixed units in source plots are separated into panels. Full-chain overview curves map to these existing state panels and are not repeated. Module 5 metrics consolidate two numerically identical aliases: on_target_editing_fraction = on_target_editing_rate; ldlr_binding_risk_proxy = apoe2_like_fraction. Model flux/metric arrays were evaluated from saved states with supplied base_config.yaml using original functions; raw state arrays are unchanged.',list(dict.fromkeys(sources)),pd.DataFrame(table))
 # Legacy notebook, deduplicate equal fraction panels.
 nbs=[json.loads((D/f'plot_series/notebook/NB{i:02}.json').read_text()) for i in range(1,8)]
 assert np.array_equal(nbs[2]['series'][0]['y'],nbs[3]['series'][0]['y'])
 fig,axes=grid(6)
 for ax,i in zip(axes,[0,1,2,4,5,6]):
  ax._metric=f'Legacy NB{i+1:02d}';ax._source_kind=f'NB{i+1:02d}'
  ob=nbs[i]
  if 'matrix' in ob:
   cm=LinearSegmentedColormap.from_list('orca',[C['lavender100'],purple]);mat=np.array(ob['matrix']);e=ob['extent'];im=ax.pcolormesh(np.linspace(e[0],e[1],mat.shape[1]+1),np.linspace(e[2],e[3],mat.shape[0]+1),mat,cmap=cm,shading='flat',rasterized=False);fig.colorbar(im,ax=ax,label='Final editing fraction')
  else:
   for j,s in enumerate(ob['series']):ax.plot(s['x'],s['y'],color=[purple,orange,teal,coral][j],label=s['name'])
   if len(ob['series'])>1:ax.legend(fontsize=16,loc='upper right',bbox_to_anchor=(.98,.83))
  ax.set(xlabel=ob['xlabel'],ylabel=ob['ylabel']);ax.margins(y=.12)
 finish(fig,'13_legacy_notebook','Seven legacy notebook images consolidated into six panels: the two identical editing-fraction plots appear once. Re-executed only after user approval with original parameters, RK45/default tolerances and original 20×20 parameter grid. This is an early simplified model, distinct from the v4 multisite model; no v4 biological inference should be drawn from the legacy product label. Heatmap retains source extent and orientation; color changed to ORCA sequential purple. No parameters or statistical methods changed.',[f'plot_series/notebook/NB{i:02}.json' for i in range(1,8)])
(OUT/'figure-index.json').write_text(json.dumps(records,ensure_ascii=False,indent=2))
print('COMPLETE',len(records))
