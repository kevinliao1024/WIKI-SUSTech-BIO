"""Reproduce preserved source schematics. No model is evaluated."""
from pathlib import Path
import sys,json,hashlib,subprocess,shutil
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch
from orca_plot import Theme,export
R=Path(__file__).resolve().parents[1]
O=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else R/'figures'
theme=Theme(O/'orca-figure-style.json')
theme.config['figure']['display_width_px']=960
theme.save()
purple='#2E267C';ink='#171536';lav='#E9E8FF';orange='#E89B3C';teal='#27877F';coral='#FFD1D5'
plans=[('full_model_workflow',[(.5,1.4,3.4,1.4,'Delivery','dose, route',lav),(6.1,1.4,3.8,1.4,'Distribution','blood, liver, brain',lav),(12,1.4,3.4,1.4,'BBB','transport extension',lav),(12,5.9,3.4,1.4,'Expression','mRNA to editor',lav),(6.1,4.7,3.8,1.4,'APOE edit','112 and 158',lav),(6.1,7,3.8,1.4,'Off-target','3 mechanisms',coral),(.5,5.9,3.4,1.4,'Design','recommendation',lav)],[(3.9,2.1,6.1,2.1),(9.9,2.1,12,2.1),(13.7,2.8,13.7,5.9),(12,6.3,9.9,5.4),(12,6.9,9.9,7.7),(6.1,5.4,3.9,6.3),(6.1,7.7,3.9,6.9)]),
('apoe_editing_logic',[(5.6,.7,4.8,1.6,'APOE4-like RNA','Arg112 / Arg158',lav),(.4,4.9,4.4,2.0,'APOE3-like','112 only\nCys112 / Arg158','#E3F2EF'),(5.8,4.9,4.4,2.,'Mixed edit','158 only\nArg112 / Cys158','#FFF1DB'),(11.2,4.9,4.4,2.,'APOE2-like','112 and 158\nCys112 / Cys158',coral)],[(6,2.3,2.6,4.9),(8,2.3,8,4.9),(10,2.3,13.4,4.9),(4.8,5.9,5.8,5.9),(10.2,5.9,11.2,5.9)]),
('dbtl_model_loop',[(6,0.5,4,1.5,'Design','PUF, editor, dose, time',lav),(11.5,3.75,4,1.5,'Build','construct / assay plan','white'),(6,7,4,1.5,'Test','qPCR, Western, amplicon','white'),(.5,3.75,4,1.5,'Learn','fit / reduce uncertainty','white'),(6,3.75,4,1.5,'Model','simulate / recommend',lav)],[(10,1.25,13.5,3.75),(13.5,5.25,10,7.75),(6,7.75,2.5,5.25),(2.5,3.75,6,1.25),(8,2,8,3.75),(10,4.5,11.5,4.5),(6,4.5,4.5,4.5),(8,7,8,5.25)])]

records=[]
with theme.context():
 for name,boxes,arrows in plans:
  if name in {"dbtl_model_loop", "full_model_workflow"}: continue
  fig,ax=plt.subplots(figsize=(16,9));fig.subplots_adjust(0,0,1,1);ax.set(xlim=(0,16),ylim=(9,0));ax.axis('off')
  for x,y,w,h,title,sub,fill in boxes:
   ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.0,rounding_size=0.1',facecolor=fill,edgecolor=purple,lw=1.8))
   ax.text(x+w/2,y+.43,title,ha='center',va='center',fontsize=26,color=ink)
   ax.text(x+w/2,y+h*.7,sub,ha='center',va='center',fontsize=20,color=ink,linespacing=1.3)
  for x1,y1,x2,y2 in arrows:ax.add_patch(FancyArrowPatch((x1,y1),(x2,y2),arrowstyle='-|>',mutation_scale=18,color=purple,lw=1.8,shrinkA=0,shrinkB=0))
  cap='Preserved source model schematic: '+name.replace('_',' ')+'. Directed relationships are retained from the supplied model documentation; this is not an experimentally validated mechanism.'
  if name=='apoe_editing_logic':cap+=' Author review required: the original APOE3-like → Mixed-edit arrow is unresolved. Keep this schematic out of the main webpage until confirmed.'
  source=R/'data/diagrams'/f'{name}.svg'
  paths=export(fig,O/f'14_{name}',theme,caption=cap,alt_text=cap,provenance={'source':str(source.relative_to(R)),'sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'processing':'Preserved vector relationships, shapes, and text. No raster components.'})
  records.append({'id':f'14_{name}','previous_group':f'14_{name}','svg':str(Path(paths['svg']).relative_to(R)),'png':str(Path(paths['png']).relative_to(R)),'pdf':str(Path(paths['pdf']).relative_to(R)),'panel_count':1,'panels':[],'caption':cap,'sources':[f'diagrams/{name}.svg'],'main_page_eligible':name!='apoe_editing_logic'})
  plt.close(fig)
# The revised workflow is an original icon drawing, not a model evaluation.
workflow = O / '14_full_model_workflow'
subprocess.run([sys.executable, str(R / 'figures/14_full_model_workflow/generate.py'), str(workflow)], check=True)
for source, target in [('icon-workflow.svg', 'figure.svg'), ('icon-workflow.pdf', 'figure.pdf'), ('icon-workflow.png', 'figure@2x.png')]:
 shutil.copyfile(workflow / source, workflow / target)
record = next(r for r in json.loads((R / 'figures/diagram-index.json').read_text()) if r['id'] == '14_full_model_workflow')
for key, filename in [('svg', 'figure.svg'), ('pdf', 'figure.pdf'), ('png', 'figure@2x.png')]:
 record[key] = str((workflow / filename).relative_to(R))
records.insert(0, record)
(O/'diagram-index.json').write_text(json.dumps(records,indent=2))
print('Saved two source schematics')
