"""Redraw only the two-dose trajectory figure from frozen, unchanged arrays."""
from pathlib import Path
import csv,json,hashlib,sys
import xml.etree.ElementTree as ET
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator
from orca_plot import Theme,export

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data'
OUT=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT/'figures'
SLUG='02_trajectories_and_uncertainty-01'
theme=Theme(OUT/'orca-figure-style.json')
theme.config['text'].update(label_pt=19,tick_pt=17,legend_pt=17,annotation_pt=18)
theme.config['figure']['display_width_px']=960
theme.save()
names=['S_APOE4','S_APOE3_like','S_APOE2_like','S_APOE158_only']
labels=['APOE4','APOE3-like','APOE2-like','158-only']
colors=[theme.c[k] for k in ['muted','teal600','coral400','orange500']]
styles=['-','-','-','--']
runs=[('run_dose0p5_t168',.5),('run_dose2_t168',2.)]
inputs=[];checks=[];table=[]
caption='Two saved v4 trajectories: dose 0.5 and dose 2.0, both 168 h. Fractions are normalized by the recorded total APOE RNA pool. Panels A and B correspond to dose 0.5 and dose 2.0, respectively. The shared legend applies to both panels. Model predictions; no model computation or parameter changes were made for this layout revision.'
with theme.context():
    fig,axes=plt.subplots(1,2,figsize=(13.5,5.95),layout='constrained')
    fig.set_constrained_layout_pads(w_pad=.14,h_pad=.16,wspace=.10,hspace=.14)
    for i,(ax,(run,dose)) in enumerate(zip(axes,runs)):
        rel=f'new_results/{run}/simulation_results.npz'
        path=DATA/rel
        inputs.append({'path':rel,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
        with np.load(path,allow_pickle=True) as z:
            idx={str(s):j for j,s in enumerate(z['state_order'])}
            t=z['t'].copy();state=z['y'].copy()
        pool=sum(state[idx[s]] for s in names)
        assert np.isfinite(t).all() and np.isfinite(pool).all() and np.all(pool>0)
        for name,label,color,style in zip(names,labels,colors,styles):
            values=state[idx[name]]/pool
            line,=ax.plot(t,values,color=color,label=label,ls=style)
            assert np.array_equal(line.get_xdata(),t)
            assert np.array_equal(line.get_ydata(),values)
            checks.append({'dose':dose,'species':name,'points':len(t),'x_array_sha256':hashlib.sha256(t.tobytes()).hexdigest(),'y_array_sha256':hashlib.sha256(values.tobytes()).hexdigest(),'identical_to_frozen_array':True})
            table.extend({'dose':dose,'species':name,'time_h':float(x),'fraction':float(y)} for x,y in zip(t,values))
        ax.set(xlabel='Time (h)',ylabel='APOE RNA fraction',ylim=(0,1.1))
        ax.xaxis.set_major_locator(MaxNLocator(nbins=4))
        ax.text(-.15,1.04,chr(65+i),transform=ax.transAxes,va='bottom',ha='left',fontsize=24,color=theme.c['ink'])
        ax.text(.5,1.045,f'Dose {dose:g}',transform=ax.transAxes,ha='center',va='bottom',fontsize=18,color=theme.c['ink'])
        assert np.allclose(ax.get_xlim(),(-8.4,176.4),rtol=0,atol=1e-12)
        assert ax.get_ylim()==(0.,1.1)
    handles,legend_labels=axes[0].get_legend_handles_labels()
    legend=fig.legend(handles,legend_labels,loc='outside lower center',ncol=4,fontsize=17,frameon=False,columnspacing=1.8,handlelength=2.5)
    fig.canvas.draw()
    renderer=fig.canvas.get_renderer()
    legend_box=legend.get_window_extent(renderer)
    layout_checks=[]
    for i,ax in enumerate(axes):
        axes_box=ax.get_window_extent(renderer)
        assert not legend_box.overlaps(axes_box)
        assert all(not text.get_window_extent(renderer).overlaps(axes_box) for text in ax.texts)
        layout_checks.append({'panel':chr(65+i),'legend_outside_axes':True,'dose_and_panel_labels_outside_axes':True,'xlim':list(ax.get_xlim()),'ylim':list(ax.get_ylim()),'xticks':list(ax.get_xticks()),'yticks':list(ax.get_yticks())})
    provenance={'inputs':inputs,'processing':'Layout-only revision of frozen trajectories. The four species, colors, line styles, pool normalization, every data point, and axis limits are unchanged. Shared legend moved below both panels; dose labels moved above plotting areas. No ODE, notebook, parameter scan, or model rerun.','panels':[{'label':chr(65+i),'metric':f'Dose {dose:g}','line_count':4,'line_points':4*checks[i*4]['points']} for i,(_,dose) in enumerate(runs)],'layout_checks':layout_checks,'numeric_checks':checks}
    paths=export(fig,OUT/SLUG,theme,caption=caption,alt_text='Two APOE RNA fraction trajectories at doses 0.5 and 2.0, with dose labels above the panels and a shared species legend below.',provenance=provenance)
    with (OUT/SLUG/'plotted-data.csv').open('w',newline='') as h:
        writer=csv.DictWriter(h,fieldnames=['dose','species','time_h','fraction']);writer.writeheader();writer.writerows(table)
    image_nodes=sum(n.tag.rsplit('}',1)[-1]=='image' for n in ET.parse(paths['svg']).getroot().iter())
    assert image_nodes==0
    report={'figure':SLUG,'data_curves':len(checks),'data_points':len(table),'frozen_array_equality':True,'model_recomputed':False,'svg_image_nodes':image_nodes,'layout_checks':layout_checks,'input_checksums':inputs}
    qa=OUT/'qa';qa.mkdir(exist_ok=True)
    (qa/'trajectory-validation.json').write_text(json.dumps(report,indent=2))
    plt.close(fig)
print(json.dumps({'output':str(OUT/SLUG),'data_curves':len(checks),'data_points':len(table),'svg_image_nodes':image_nodes}))
