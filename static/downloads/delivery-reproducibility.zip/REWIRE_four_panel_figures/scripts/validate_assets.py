"""Validate a rendered package; only Python's standard library is required."""
from pathlib import Path
import csv,json,hashlib,xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
manifest=json.loads((ROOT/'software-figure-manifest.json').read_text())
results=[]
for figure in manifest['figures']:
    svg=ROOT/figure['svg']
    xml=ET.parse(svg).getroot()
    images=sum(node.tag.rsplit('}',1)[-1]=='image' for node in xml.iter())
    assert images==0,(figure['id'],'raster image found')
    assert 1<=figure['panel_count']<=4,figure['id']
    assert (ROOT/figure['png']).is_file()
    assert (ROOT/figure['pdf']).is_file()
    for item in figure['sources']:
        assert (ROOT/'data'/item).is_file(),item
    results.append({'id':figure['id'],'panel_count':figure['panel_count'],'svg_image_nodes':images,'svg_sha256':hashlib.sha256(svg.read_bytes()).hexdigest()})
coverage=list(csv.DictReader((ROOT/'coverage.csv').open()))
assert len(coverage)==62,len(coverage)
ids={f['id'] for f in manifest['figures']}
for row in coverage:
    assert row['new_groups']
    assert set(row['new_groups'].split(';')).issubset(ids),row
print(json.dumps({'figures':len(results),'source_figures_covered':len(coverage),'maximum_panels':max(v['panel_count'] for v in results),'raster_images':sum(v['svg_image_nodes'] for v in results),'checks':results},indent=2))
