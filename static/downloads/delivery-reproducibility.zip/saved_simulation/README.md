# Saved simulation evidence

The browser compact data are `../website/static/assets/software/brain-delivery/brain-delivery-spatial.json`. They contain 3 saved relative-dose scenarios (0.3, 1 and 3), 37 time frames per scenario (0–72 h at 2 h intervals), all 1,480 fixed cells, and 288 exact field samples per frame. The original field has 36,000 points; every fifth index in each axis is retained for display. No averaging, interpolation or numerical rounding was applied during extraction. Scalar metrics were checked against the full original arrays and source CSV files, not the subsampled field.

The 111 frames are saved computed outcomes of a one-way PBPK-driven PhysiCell–BioFVM tissue microdomain. They are not a full human anatomical simulation or experimental validation. Cell-type effects and uptake assumptions are configurable demonstration priors. Relative AAV quantities are not clinical doses. `final-verification.json` records units, numerical checks and limitations.

`source/` contains audit selections only. It does not contain a complete runnable PhysiCell project, all dependencies, or the raw VTI/VTP series. In particular, the included PVD index files cannot independently open the complete sequence. Two source text files containing author-specific filesystem paths are omitted; their original hashes remain in `AUDIT_SUBSET_MANIFEST.json` and `consumed-source-manifest.json`.

For the complete original spatial source and raw output series, recover the directory `brain_delivery_model/XiaobxTim-iGEM-REWIRE-iterated-v4/` from the supplied `brain_delivery_model.zip` (SHA-256 `30bc8d2e783251867d12d39de290a099c1e2457df5ec1932681bb50b7a849d22`). Follow that project's own environment and build instructions. The adjacent REWIRE_model_toolkit contains the compact ODE source distribution; it does not contain the complete spatial_model project. No third-party binary or new environment is distributed here.

To reproduce extraction using Python's standard library and the original archive, choose a new output directory:

```bash
python saved_simulation/prepare_saved_data.py brain_delivery_model.zip --output-dir extracted-saved-data
```

This reads the original saved outputs and verifies their arrays and hashes; it never imports or runs the scientific model. The original extractor is retained byte for byte at `audit/prepare_saved_data.original.py`. The portable entry changes only argument parsing and output location: the required `--output-dir` must not already exist. Decoding, array selection, scientific labels, thresholds and assertions are unchanged. Running the extractor reproduces the original audit subset, including author-specific source text; the public bundle deliberately omits those two files.

`full-chain-baseline.json` is a separate saved 34-state ODE trajectory (97 time points, 0–48 h, footpad route). It is not the same run as the 72-hour spatial output, and is not used to animate the body schematic. The body animation depicts process order only; particle speed, abundance and travel time have no numerical interpretation.
