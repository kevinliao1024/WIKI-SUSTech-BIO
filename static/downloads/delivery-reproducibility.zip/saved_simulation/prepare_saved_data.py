"""Decode existing saved outputs only; never imports or executes the model.

Python standard library only. Usage: python3 prepare_saved_data.py SOURCE.zip --output-dir NEW_DIR
Writes new files to the required new output directory and refuses to overwrite.
"""
import argparse
import ast
import base64
from collections import Counter
import csv
import hashlib
import io
import json
import math
from pathlib import Path, PurePosixPath
import pickletools
import stat
import struct
import sys
import xml.etree.ElementTree as ET
import zipfile
import zlib

parser = argparse.ArgumentParser(description="Decode saved outputs only; no model is run.")
parser.add_argument("source_zip", type=Path, help="Original brain_delivery_model.zip")
parser.add_argument("--output-dir", type=Path, required=True, help="A new directory; existing directories are refused")
args = parser.parse_args()
OUT = args.output_dir.resolve()
OUT.mkdir(parents=True, exist_ok=False)
BASE = 'brain_delivery_model/XiaobxTim-iGEM-REWIRE-iterated-v4/'
SPATIAL = 'outputs/physicell_brain_delivery/'
consumed = {}


def save(name, data):
    p = OUT / name
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('xb') as handle:
        handle.write(data)


def save_json(name, obj):
    save(name, (json.dumps(obj, ensure_ascii=False, separators=(',', ':'), allow_nan=False) + '\n').encode())


def read(z, name):
    data = z.read(BASE + name)
    consumed[name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    return data


def table(data):
    return [{k: (v if k == 'scenario' else float(v)) for k, v in row.items()}
            for row in csv.DictReader(io.StringIO(data.decode()))]


def decode_array(root, name):
    a = next(a for a in root.findall('.//DataArray') if a.get('Name') == name)
    assert root.get('byte_order') == 'LittleEndian'
    assert root.get('header_type') == 'UInt32'
    assert root.get('compressor') == 'vtkZLibDataCompressor'
    assert root.find('AppendedData').get('encoding') == 'base64'
    encoded = root.find('AppendedData').text.strip()[1:][int(a.get('offset')):]
    n, block_size, last_size = struct.unpack('<3I', base64.b64decode(encoded[:16]))
    header_length = ((3 + n) * 4 + 2) // 3 * 4
    header = struct.unpack('<' + 'I' * (3 + n), base64.b64decode(encoded[:header_length]))
    sizes = header[3:]
    data_length = (sum(sizes) + 2) // 3 * 4
    compressed = base64.b64decode(encoded[header_length:header_length + data_length])
    pieces, pos = [], 0
    for size in sizes:
        pieces.append(zlib.decompress(compressed[pos:pos + size]))
        pos += size
    raw = b''.join(pieces)
    assert len(raw) == (n - 1) * block_size + last_size
    code = {'Float64': 'd', 'Int32': 'i', 'Int64': 'q', 'UInt8': 'B'}[a.get('type')]
    values = list(struct.unpack('<' + code * (len(raw) // struct.calcsize(code)), raw))
    assert all(math.isfinite(v) for v in values)
    return values


def triples(values):
    return [values[i:i + 3] for i in range(0, len(values), 3)]


def close(actual, expected):
    assert math.isclose(actual, expected, rel_tol=1e-11, abs_tol=1e-28), (actual, expected)


def npy_header(data):
    assert data[:8] == b'\x93NUMPY\x01\x00'
    length = struct.unpack('<H', data[8:10])[0]
    return ast.literal_eval(data[10:10 + length].decode()), data[10 + length:]


source = args.source_zip
source_sha = hashlib.file_digest(source.open('rb'), 'sha256').hexdigest() if hasattr(hashlib, 'file_digest') else hashlib.sha256(source.read_bytes()).hexdigest()
with zipfile.ZipFile(source) as z:
    infos = z.infolist()
    for info in infos:
        p = PurePosixPath(info.filename)
        assert not p.is_absolute() and '..' not in p.parts and '\\' not in info.filename
        assert not stat.S_ISLNK(info.external_attr >> 16)
    inventory = {'source_zip': source.name, 'sha256': source_sha, 'archive_bytes': source.stat().st_size,
                 'entries': len(infos), 'uncompressed_bytes': sum(i.file_size for i in infos),
                 'unsafe_paths': 0, 'symlinks': 0,
                 'top_branches': dict(Counter({}))}
    counter = Counter()
    for info in infos:
        if info.filename.startswith(BASE):
            counter[info.filename[len(BASE):].split('/')[0]] += info.file_size
    inventory['v4_branch_uncompressed_bytes'] = dict(counter)
    metadata = json.loads(read(z, SPATIAL + 'run_metadata.json'))
    checks = json.loads(read(z, SPATIAL + 'scientific_checks.json'))
    metrics_data = read(z, SPATIAL + 'dose_comparison_metrics.csv')
    all_metrics = table(metrics_data)
    save('source/dose_comparison_metrics.csv', metrics_data)
    small_sources = [
        'README.md', 'spatial_model/README_CN.md', 'spatial_model/paraview_export.py',
        'spatial_model/raw_output.py', 'spatial_model/run_pipeline.py',
        'spatial_model/pbpk_boundary.py', 'spatial_model/tissue_geometry.py',
        'spatial_model/physicell_project/brain_delivery.cpp',
        'models/full_model/state_vector.py', 'config/base_config.yaml',
        'docs/plans/2026-08-29-physicell-brain-delivery-design.md',
        SPATIAL + 'run_metadata.json', SPATIAL + 'scientific_checks.json',
        SPATIAL + 'logs/build.log', SPATIAL + 'logs/comparison_validate.log',
    ]
    for name in small_sources:
        save('source/' + name, read(z, name))
    field_indices = [x + 40 * (y + 30 * zz) for zz in range(0, 30, 5) for y in range(0, 30, 5) for x in range(0, 40, 5)]
    field_positions = [[-195 + 10 * x, -145 + 10 * y, -145 + 10 * zz]
                       for zz in range(0, 30, 5) for y in range(0, 30, 5) for x in range(0, 40, 5)]
    data = {
        'schema_version': 1,
        'title': 'Saved PhysiCell–BioFVM brain delivery simulation',
        'bounds_um': [[-200, 200], [-150, 150], [-150, 150]],
        'times_h': list(range(0, 73, 2)), 'times_min': list(range(0, 4321, 120)),
        'field_positions_um': field_positions,
        'field_sampling': {'original_shape_xyz': [40, 30, 30], 'original_spacing_um': [10, 10, 10],
                           'sample_shape_xyz': [8, 6, 6], 'stride_xyz': [5, 5, 5],
                           'index_order': 'x fastest, then y, then z',
                           'method': 'Exact saved values at indices 0,5,10,... on each axis; no averaging or interpolation.'},
        'cell_type_names': {'0': 'endothelial', '1': 'neuron', '2': 'astrocyte'},
        'cells': {}, 'doses': [],
        'units': {'position': 'µm', 'time': 'min (times_h = min / 60)',
                  'dose': 'relative dose; medium dose = 1.0',
                  'field_values': 'normalized extracellular AAV density; source declares normalized, integral uses voxel volume in µm³',
                  'editing_fraction': 'dimensionless fraction; multiply by 100 for percent',
                  'extracellular_AAV_mass': 'normalized AAV amount',
                  'BBB_release_rate': 'normalized AAV amount per min',
                  'off_target_burden': 'dimensionless accumulated off-target events / total modeled APOE pool'},
        'provenance': {'source_zip': source.name, 'source_zip_sha256': source_sha,
                       'archive_root': BASE.rstrip('/'), 'source_result_path': SPATIAL.rstrip('/'),
                       'created_utc_in_source': metadata['created_utc'], 'physicell_version': metadata['physicell_version'],
                       'paraview_version': '6.0.1', 'seed': metadata['seed'],
                       'source_frames_per_dose': 37, 'all_time_frames_retained': True,
                       'all_cells_retained': True, 'numeric_rounding': 'none; JSON float round-trip',
                       'model_rerun': False,
                       'interpretation': 'Saved numerical simulations with configurable demonstration priors, not calibrated in vivo or clinical predictions. One-way PBPK input drives a tissue microdomain; this is not a whole-human anatomy or fluid-flow simulation.'},
        'metric_definitions': {
            'editing_fraction': '(S_APOE3_like + S_APOE2_like) / (four free APOE states + four complexes + 1e-12)',
            'brain_cell_editing_mean': 'Arithmetic mean over 800 neurons and 400 astrocytes; excludes endothelial cells.',
            'off_target_burden': '(B_local_bystander + E_puf_off + E_deaminase_bg) / total modeled APOE pool',
            'near_far': 'Near/far are bottom/top quartiles of cell distance to vessel among brain cells, not fixed distance thresholds.'},
        'source_scientific_checks': checks,
    }
    validation = {'frames_decoded': 0, 'cell_count': 1480, 'grid_point_count': 36000,
                  'summary_matches_full_decoded_data': True, 'geometry_identical_across_all_frames_and_doses': True,
                  'source_input_hashes_verified': True, 'vtk_arrays_finite_nonnegative': True,
                  'model_run': False, 'original_files_modified': False, 'dose_details': {}}
    global_field_max, global_edit_max = 0.0, 0.0
    for dose, scenario in [(0.3, 'dose_0p3'), (1.0, 'dose_1p0'), (3.0, 'dose_3p0')]:
        prefix = SPATIAL + scenario + '/'
        for filename in ['inputs/brain_blood_input.csv', 'inputs/cells.csv', 'inputs/spatial_parameters.cfg',
                         'mass_balance.csv', 'paraview/metrics.csv', 'paraview/simulation.pvd']:
            save('source/' + scenario + '/' + filename, read(z, prefix + filename))
        for key, filename in [('boundary', 'inputs/brain_blood_input.csv'), ('cells', 'inputs/cells.csv'), ('parameters', 'inputs/spatial_parameters.cfg')]:
            assert consumed[prefix + filename]['sha256'] == metadata['input_sha256'][scenario][key]
        save('source/' + scenario + '/physicell.log', read(z, SPATIAL + 'logs/' + scenario + '_physicell.log'))
        pvd = ET.fromstring(read(z, prefix + 'paraview/simulation.pvd'))
        times = [float(e.get('timestep')) for e in pvd.findall('Collection/DataSet')]
        assert times == data['times_min']
        summary = [r for r in all_metrics if r['scenario'] == scenario]
        assert len(summary) == 37
        scenario_data = {'dose': dose, 'scenario': scenario, 'field_values': [], 'editing_fraction': [],
                         'summary': summary, 'boundary': table(read(z, prefix + 'inputs/brain_blood_input.csv')),
                         'mass_balance': table(read(z, prefix + 'mass_balance.csv'))}
        for frame in range(37):
            cells_root = ET.fromstring(read(z, prefix + f'paraview/cells/frame_{frame:04d}.vtp'))
            cell_geometry = {'positions_um': triples(decode_array(cells_root, 'Points')),
                             'types': decode_array(cells_root, 'cell_type'), 'ids': decode_array(cells_root, 'cell_id'),
                             'radius_um': decode_array(cells_root, 'radius_um'),
                             'distance_to_vessel_um': decode_array(cells_root, 'distance_to_vessel_um')}
            if not data['cells']:
                data['cells'] = cell_geometry
                assert Counter(data['cells']['types']) == {0: 280, 1: 800, 2: 400}
                assert data['cells']['ids'] == list(range(1480))
            else:
                assert data['cells'] == cell_geometry
            editing = decode_array(cells_root, 'editing_fraction')
            off_target = decode_array(cells_root, 'off_target_burden')
            assert len(editing) == 1480 and min(editing) >= 0 and min(off_target) >= 0
            field_root = ET.fromstring(read(z, prefix + f'paraview/fields/frame_{frame:04d}.vti'))
            im = field_root.find('ImageData')
            assert im.get('WholeExtent') == '0 39 0 29 0 29'
            assert im.get('Origin') == '-195 -145 -145' and im.get('Spacing') == '10 10 10'
            field = decode_array(field_root, 'extracellular_AAV')
            assert len(field) == 36000 and min(field) >= 0
            row = summary[frame]
            close(row['time_min'], times[frame])
            close(sum(field) * 1000, row['extracellular_AAV_mass'])
            kinds = data['cells']['types']
            close(sum(v for v, t in zip(editing, kinds) if t == 1) / 800, row['neuron_editing_mean'])
            close(sum(v for v, t in zip(editing, kinds) if t == 2) / 400, row['astrocyte_editing_mean'])
            close(sum(v for v, t in zip(editing, kinds) if t in (1, 2)) / 1200, row['brain_cell_editing_mean'])
            close(sum(v for v, t in zip(off_target, kinds) if t in (1, 2)) / 1200, row['brain_cell_off_target_mean'])
            scenario_data['field_values'].append([field[i] for i in field_indices])
            scenario_data['editing_fraction'].append(editing)
            global_field_max = max(global_field_max, max(field))
            global_edit_max = max(global_edit_max, max(editing))
            validation['frames_decoded'] += 1
        mass_error = max(r['relative_error'] for r in scenario_data['mass_balance'])
        close(mass_error, metadata['mass_balance_max_relative_error'][scenario])
        validation['dose_details'][scenario] = {'mass_balance_max_relative_error': mass_error,
                                               'final_summary': summary[-1]}
        data['doses'].append(scenario_data)
    data['global_ranges'] = {'field_values': [0, global_field_max], 'editing_fraction': [0, global_edit_max],
                             'source_log10_field_floor': 1e-18}
    save_json('brain-delivery-spatial.json', data)
    # A separate frozen 48-hour full-chain ODE baseline is optional for the anatomical schematic.
    # Never unpickle object arrays. Parse only primitive numeric NPY arrays and inspect pickle opcodes.
    npz_path = 'reports/iterated_analysis/baseline/simulation_results.npz'
    npz_data = read(z, npz_path)
    save('source/full-chain-baseline/simulation_results.npz', npz_data)
    state_source = read(z, 'models/full_model/state_vector.py').decode()
    tree = ast.parse(state_source)
    state_names = next(ast.literal_eval(n.value) for n in tree.body if isinstance(n, ast.AnnAssign) and getattr(n.target, 'id', '') == 'STATE_ORDER')
    with zipfile.ZipFile(io.BytesIO(npz_data)) as nz:
        th, traw = npy_header(nz.read('t.npy'))
        yh, yraw = npy_header(nz.read('y.npy'))
        sh, sraw = npy_header(nz.read('state_order.npy'))
        assert th['descr'] == yh['descr'] == '<f8' and not th['fortran_order'] and not yh['fortran_order']
        names_in_pickle = [arg for op, arg, _ in pickletools.genops(sraw) if op.name in ('SHORT_BINUNICODE', 'BINUNICODE') and arg in state_names]
        assert names_in_pickle == state_names
        times = list(struct.unpack('<' + 'd' * th['shape'][0], traw))
        flat = list(struct.unpack('<' + 'd' * (yh['shape'][0] * yh['shape'][1]), yraw))
        assert yh['shape'] == (len(state_names), len(times))
        ode = {'schema_version': 1, 'source_result_path': npz_path, 'times_h': times,
               'metadata': json.loads(read(z, 'reports/iterated_analysis/baseline/metadata.json')),
               'states': {name: flat[i * len(times):(i + 1) * len(times)] for i, name in enumerate(state_names)},
               'provenance': {'source_zip_sha256': source_sha, 'model_rerun': False,
                              'note': 'Separate 0–48 h ODE baseline; do not present as the 0–72 h spatial simulation or human-calibrated physiology.'}}
        save_json('full-chain-baseline.json', ode)
    save_json('inventory.json', inventory)
    save_json('validation.json', validation)
    save_json('consumed-source-manifest.json', consumed)
    print(json.dumps({'spatial_json_bytes': (OUT / 'brain-delivery-spatial.json').stat().st_size,
                      'ode_json_bytes': (OUT / 'full-chain-baseline.json').stat().st_size,
                      'frames': validation['frames_decoded'], 'doses': 3, 'cells': 1480, 'sampled_field_points': len(field_indices),
                      'ranges': data['global_ranges'], 'final': validation['dose_details']}, indent=2))
