# Delivery model reproducibility bundle — revision 5

This single bundle contains reusable REWIRE ODE source code, the ORCA figure set, a human-body process schematic, and browser replay of existing saved spatial simulation outputs. Packaging does not rerun scientific models, fit parameters, change thresholds, or recompute data. Original model files and frozen plotting inputs remain byte-identical to their supplied distributions.

Revision 5 synchronizes the richer 3D process animation and saved-data spatial viewer from the Wiki. The four final data stories remain unchanged from revision 4. The preceding revision is preserved separately; scientific source, frozen plotting arrays, saved spatial data and model methods are unchanged. The exact final page text is used; no intermediate prose draft is included.

## Open the saved-output demonstration

From this extracted bundle's root, use any local static HTTP server. Python's standard-library server is sufficient:

```bash
python -m http.server 8000 --bind 127.0.0.1
```

Open `http://127.0.0.1:8000/website/preview.html`. Serve the bundle root (rather than the website subdirectory) so the workflow figure's relative path resolves. The page uses local HTML, CSS, JavaScript, JSON and the bundled Three.js r186 source, with no network service, scientific calculation, or installation. The interactive 3D views require JavaScript and WebGL 2. If 3D is unavailable, the schematic fallback and saved source data remain available; the spatial view reports a load problem and provides a retry control. Use the served URL rather than opening the file directly, since browsers restrict local-file fetches.

The body is a **process schematic**: motion communicates administration/depot, circulation/distribution, BBB transport, uptake/expression, RNA editing and a separate clearance branch. Play runs the selected stage once and then pauses on that stage; replay restarts the same selection. Its particles do not encode concentration, anatomical accuracy or simulation time. BBB recycling returns to the blood side. The adjacent spatial viewer replays **111 saved frames**: three relative-dose scenarios × 37 times from 0 to 72 h. All 1,480 cells and all time frames are retained; the field display uses 288 exact original grid values per frame. See `saved_simulation/README.md` for provenance, units and limits. Playback, rotation and filters do not execute a scientific model.

## Reuse the software

`REWIRE_model_toolkit/` keeps the original top-level directory and all 55 scientific source/config/template/test files unchanged. It also includes the previous packaging README, citation correction, dependency records and smoke-check script. Read its README before running a model. In a compatible existing environment, a cheap CLI check is:

```bash
cd REWIRE_model_toolkit
python main.py --help
python smoke_check.py
```

The smoke check is a short software fixture, not reproduction of the full figures. It was validated in the prior toolkit release; this bundle only repeats static integrity checks. The toolkit is a compact ODE distribution, not a complete PhysiCell project. Instructions for recovering the original complete spatial project and raw series are in `saved_simulation/README.md`.

## Figures and source layout

- `REWIRE_four_panel_figures/`: 39 independent SVG/PDF/PNG figures (37 data figures with at most four panels, plus two source schematics); 62 original figure occurrences are mapped in coverage.csv. The DBTL figure is excluded. The unresolved APOE editing schematic is retained for audit but remains ineligible for the main page.
- `REWIRE_four_panel_figures/figures/14_full_model_workflow/`: revised original icon workflow, SVG/PDF/PNG, caption, source, provenance and deterministic `generate.py`. The endpoint label is Model comparison. Icons contain no numerical data. SVG text remains editable; font availability can affect appearance.
- `website/software-data-stories.html`: the four final Wiki stories copied verbatim into the standalone preview. `website/source-snapshot/` preserves the exact page template and metadata/prose file for audit, with hashes in `website/NARRATIVE_SOURCE_MANIFEST.json`. `website/story-evidence.json` preserves the final numerical audit; its paths describe the original audit workspace, not runnable paths in this archive. `website/story-evidence-packaged-sources.json` maps those hashes to byte-identical packaged files. The full Wiki and PUF tutorial are not bundled; these snapshots are source records, not additional standalone pages.
- `website/wiki/components/software/` and `website/static/`: exact component HTML/CSS/JS and supporting scene modules used in the Wiki, plus a standalone preview that expands the local component include and replaces template URL placeholders. The body, BBB/cell/RNA process mechanisms and saved spatial replay remain separate presentation components. The local software-spatial-scene-3d.js module renders exact saved values; its viewing slice and camera are display controls. Its capillary cylinder uses the original nominal radius (12 μm), x-axis direction and centered geometry; type-specific cell meshes are display glyphs at saved centers and radii, not reconstructed morphology. Slice filtering does not change full-population summary means or the fixed color domains.
- `website/static/assets/software/body-3d/` and `website/static/software-delivery-body-3d.js`: original continuous body mesh, visual-generation source/parameters/provenance, and the local WebGL scene. These are artistic, nonclinical geometry and use no patient imaging. Generating the surface is optional and needs NumPy; it does not rerun a biological model. Supply a new output directory when invoking `generate_body.py`.
- `website/static/assets/software/brain-delivery/brain-delivery-spatial.json`: compact saved values consumed by the viewer, unchanged from the validated extraction.
- `saved_simulation/`: portable saved-output extractor, original extractor audit copy, immutable selected CSV/config/source evidence, manifests, validation and a separately identified saved ODE baseline.

For figure reproduction from the frozen arrays, follow `REWIRE_four_panel_figures/README.txt`. Existing graphical generators remain available and the diagram generator now invokes the icon workflow generator. Use a new output directory; no static figure or body-mesh generator was run while assembling this bundle. Original frozen plotting inputs remain unchanged, including the prior workflow source. The icon revision adds a separately identified vector source.

## Integrity, scope and licensing

Run `python verify_bundle.py` from this root to verify every packaged file against SHA256SUMS (Python standard library only). `SOURCE_MANIFEST.json` records input archives, original-file checks and display-only changes; `VALIDATION.json` records the checks actually executed at packaging. `saved_simulation/final-verification.json` records the earlier full saved-array validation, which was not rerun during bundling. Numeric simulations are exploratory and are not experimental or clinical validation.

The literature correction in `REWIRE_model_toolkit/CITATION_NOTES.txt` identifies Liu et al. (2024), DOI 10.1016/j.xphs.2023.10.005, and limits its parameter claims. Original scientific documentation is preserved unchanged.

No new license is granted by this bundle. See `REWIRE_model_toolkit/LICENSE_STATUS.txt`; the supplied model did not include an explicit reuse license. Packaging and readable source availability do not establish permission to redistribute that model. The separately identified Three.js r186 source retains its existing MIT license at `website/static/vendor/three/LICENSE.txt`; its two JavaScript modules and license are copied byte for byte from the Wiki's existing vendor directory. No third-party binary, credentials, or author-specific absolute filesystem paths are included. Full raw spatial frames are not bundled, and the selected source/PVD index files cannot independently rerun PhysiCell or open a full ParaView sequence.
