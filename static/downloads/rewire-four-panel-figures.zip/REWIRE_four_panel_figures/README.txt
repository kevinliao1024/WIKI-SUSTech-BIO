REWIRE ORCA Software figure assets — four-panel edition

39 independent SVG/PDF/PNG figures: 37 data figures plus 2 source schematics.
Each data figure has at most four actual scientific panels; no stitched atlas is included.
coverage.csv maps 62 supplied figure occurrences to their new outputs.
software-figure-manifest.json contains titles, external captions, panel labels, and recommended webpage placement.

Quick use
Embed figures/<id>/figure.svg at the full content width. The figures use path-based text and do not require the viewer to install Futura. Keep each caption outside the SVG. On small screens provide a zoom/full-size link.
The PNG previews are 1920 px wide. PDF is available for publication/export.

Reproduce from frozen data
Use an existing Python 3.12 environment with the versions in requirements.txt, or an isolated environment chosen by the user. No install is performed by these scripts.
From this package directory:
    python scripts/redraw.py figures-redrawn
    python scripts/redraw_diagrams.py figures-redrawn
These commands create a new output folder and do not rerun any ODE model, parameter scan, or notebook. Existing output files are not overwritten.
Source arrays are in data/. Frozen copies are identical to the prior deliverable; see frozen-data-checksums.json.
The scripts and ORCA plotting helper are portable. No local absolute paths or commercial font files are included. Futura is used when available, with Arial/DejaVu Sans fallback documented by each exported figure manifest.

Validate delivered assets
    python scripts/validate_assets.py
Checks all SVGs for raster image nodes, panel counts <= 4, source availability, and 62-figure coverage after the requested DBTL exclusion. See qa/validation.json for this delivery's inspected run.

Scientific scope
These are model predictions and recorded model benchmark statuses, not experimental results or clinically validated boundaries. Criteria, thresholds, model labels and stored methods are unchanged.
The source runs do not contain a complete per-run configuration snapshot; earlier derived fluxes/metrics used the supplied base configuration. This edition reads those frozen arrays and does not reevaluate them.
The early notebook model remains separate from the v4 multisite model. NB03/NB04 are the same curve and appear once.
The unresolved APOE3-like -> Mixed-edit arrow is retained for source completeness in figures/14_apoe_editing_logic, marked main_page_eligible=false. Exclude it from the main Software page pending author review.

This package supplies figure reproduction only. The website's reusable model/software package is a separate download.

Revision 2
The DBTL figure is excluded from this Software edition. Its original input remains in data/ for provenance.
The trajectory figure uses a shared legend below the panels and dose labels above the axes. Its 8 curves / 6728 points are unchanged.
For only that figure, run python scripts/redraw_trajectories.py figures-trajectory-redrawn.
