Preserved source model schematic: full model workflow. Directed relationships are retained from the supplied model documentation; this is not an experimentally validated mechanism.
